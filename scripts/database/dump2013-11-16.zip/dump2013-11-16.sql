--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: blast_query; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE blast_query (
    id bigint NOT NULL,
    version bigint NOT NULL,
    query_sequence character varying(255)
);


ALTER TABLE public.blast_query OWNER TO ndunn;

--
-- Name: category; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    note character varying(255),
    type character varying(255),
    units character varying(255)
);


ALTER TABLE public.category OWNER TO ndunn;

--
-- Name: encrypted_data; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE encrypted_data (
    id character varying(32) NOT NULL,
    version bigint NOT NULL,
    data_item character varying(512)
);


ALTER TABLE public.encrypted_data OWNER TO ndunn;

--
-- Name: experiment; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE experiment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    note character varying(255),
    researcher_id bigint,
    when_performed timestamp without time zone
);


ALTER TABLE public.experiment OWNER TO ndunn;

--
-- Name: genome; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE genome (
    id bigint NOT NULL,
    version bigint NOT NULL,
    external_id character varying(255) NOT NULL,
    genome_type_id bigint NOT NULL,
    genome_version real,
    note character varying(255),
    quality integer,
    size real,
    strain_id bigint,
    fasta16s_sequence character varying(255)
);


ALTER TABLE public.genome OWNER TO ndunn;

--
-- Name: genome_type; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE genome_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    base_url character varying(255) NOT NULL,
    organization_name character varying(255) NOT NULL
);


ALTER TABLE public.genome_type OWNER TO ndunn;

--
-- Name: genus; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE genus (
    id bigint NOT NULL,
    version bigint NOT NULL,
    host boolean,
    name character varying(255) NOT NULL,
    phylum_id bigint NOT NULL
);


ALTER TABLE public.genus OWNER TO ndunn;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: ndunn
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO ndunn;

--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: ndunn
--

SELECT pg_catalog.setval('hibernate_sequence', 1882, true);


--
-- Name: host_facility; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE host_facility (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    prefix character varying(255)
);


ALTER TABLE public.host_facility OWNER TO ndunn;

--
-- Name: host_genotype; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE host_genotype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    zfin_id character varying(255)
);


ALTER TABLE public.host_genotype OWNER TO ndunn;

--
-- Name: host_origin; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE host_origin (
    id bigint NOT NULL,
    version bigint NOT NULL,
    anatomy character varying(255),
    anatomy_url character varying(255),
    days_past_fertilization integer,
    host_facility_id bigint NOT NULL,
    notes character varying(255),
    species_id bigint NOT NULL,
    stage character varying(255),
    population_id bigint
);


ALTER TABLE public.host_origin OWNER TO ndunn;

--
-- Name: host_origin_genotypes; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE host_origin_genotypes (
    host_genotype_id bigint NOT NULL,
    host_origin_id bigint NOT NULL
);


ALTER TABLE public.host_origin_genotypes OWNER TO ndunn;

--
-- Name: isolate_condition; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE isolate_condition (
    id bigint NOT NULL,
    version bigint NOT NULL,
    isolated_by_id bigint,
    isolated_when timestamp without time zone NOT NULL,
    media character varying(255),
    notes character varying(255),
    oxygen_condition character varying(255),
    temperature real
);


ALTER TABLE public.isolate_condition OWNER TO ndunn;

--
-- Name: lab; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE lab (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.lab OWNER TO ndunn;

--
-- Name: location; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE location (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.location OWNER TO ndunn;

--
-- Name: measured_value; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE measured_value (
    id bigint NOT NULL,
    version bigint NOT NULL,
    category_id bigint NOT NULL,
    experiment_id bigint NOT NULL,
    strain_id bigint NOT NULL,
    type character varying(255),
    value character varying(255) NOT NULL
);


ALTER TABLE public.measured_value OWNER TO ndunn;

--
-- Name: phylum; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE phylum (
    id bigint NOT NULL,
    version bigint NOT NULL,
    host boolean,
    name character varying(255) NOT NULL
);


ALTER TABLE public.phylum OWNER TO ndunn;

--
-- Name: population; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE population (
    id bigint NOT NULL,
    version bigint NOT NULL,
    capture_date timestamp without time zone,
    external_id character varying(255),
    latitude double precision,
    longitude double precision,
    name character varying(255) NOT NULL,
    notes text,
    wildtype boolean
);


ALTER TABLE public.population OWNER TO ndunn;

--
-- Name: researcher; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE researcher (
    id bigint NOT NULL,
    version bigint NOT NULL,
    first_name character varying(255) NOT NULL,
    lab_id bigint,
    last_name character varying(255) NOT NULL,
    password_hash character varying(255),
    username character varying(255)
);


ALTER TABLE public.researcher OWNER TO ndunn;

--
-- Name: researcher_permissions; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE researcher_permissions (
    researcher_id bigint,
    permissions_string character varying(255)
);


ALTER TABLE public.researcher_permissions OWNER TO ndunn;

--
-- Name: researcher_roles; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE researcher_roles (
    researcher_id bigint NOT NULL,
    role_id bigint NOT NULL
);


ALTER TABLE public.researcher_roles OWNER TO ndunn;

--
-- Name: role; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE role (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.role OWNER TO ndunn;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE role_permissions (
    role_id bigint,
    permissions_string character varying(255)
);


ALTER TABLE public.role_permissions OWNER TO ndunn;

--
-- Name: species; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE species (
    id bigint NOT NULL,
    version bigint NOT NULL,
    common_name character varying(255),
    genus_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    host boolean,
    prefix character varying(255)
);


ALTER TABLE public.species OWNER TO ndunn;

--
-- Name: species_host_genotype; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE species_host_genotype (
    species_genotypes_id bigint,
    host_genotype_id bigint
);


ALTER TABLE public.species_host_genotype OWNER TO ndunn;

--
-- Name: stock; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE stock (
    id bigint NOT NULL,
    version bigint NOT NULL,
    box_index integer NOT NULL,
    box_number integer NOT NULL,
    general_location_id bigint,
    strain_id bigint
);


ALTER TABLE public.stock OWNER TO ndunn;

--
-- Name: strain; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE strain (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date_entered timestamp without time zone,
    former_clone_alias character varying(255),
    genus_id bigint,
    host_origin_id bigint,
    isolate_condition_id bigint,
    name character varying(255) NOT NULL,
    notes text,
    parent_strain_id bigint,
    strain_genotype_id bigint,
    sequence16s text
);


ALTER TABLE public.strain OWNER TO ndunn;

--
-- Name: strain_genotype; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE strain_genotype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    note character varying(255)
);


ALTER TABLE public.strain_genotype OWNER TO ndunn;

--
-- Data for Name: blast_query; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY blast_query (id, version, query_sequence) FROM stdin;
\.


--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY category (id, version, name, note, type, units) FROM stdin;
390	0	Motility	\N	TEXT	\N
392	0	HemolyticActivity	\N	TEXT	\N
394	0	Antibiotic	\N	TEXT	\N
396	0	Doubling Time	\N	DECIMAL	\N
398	0	Adherence	\N	TEXT	\N
550	0	color	\N	TEXT	\N
551	0	colony shape	\N	TEXT	\N
985	0	Size	\N	TEXT	\N
986	0	Color	\N	TEXT	\N
987	0	Edge	\N	TEXT	\N
988	0	Raised	\N	TEXT	\N
989	0	Shape	\N	TEXT	\N
\.


--
-- Data for Name: encrypted_data; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY encrypted_data (id, version, data_item) FROM stdin;
\.


--
-- Data for Name: experiment; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY experiment (id, version, name, note, researcher_id, when_performed) FROM stdin;
391	0	Motility 1	\N	\N	\N
393	0	HemolyticActivity 1	\N	\N	\N
395	0	Antibiotic 1	\N	\N	\N
397	0	Doubling Time 1	\N	\N	\N
399	0	Adherence 1	\N	\N	\N
549	0	Colony morphology	\N	8	2013-10-03 00:00:00
569	0	091310	\N	\N	\N
730	0	060310	\N	\N	\N
807	0	062513	\N	\N	\N
870	0	063013	\N	\N	\N
908	0	071610	\N	\N	\N
924	0	080210	\N	\N	\N
930	0	063010	\N	\N	\N
936	0	070710	\N	\N	\N
\.


--
-- Data for Name: genome; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY genome (id, version, external_id, genome_type_id, genome_version, note, quality, size, strain_id, fasta16s_sequence) FROM stdin;
34	0	68767	16	\N	\N	294	4443477	29	\N
37	0	40453	16	\N	\N	714	4585056	36	\N
69	0	56182	16	\N	\N	169	4127210	67	\N
81	0	56183	16	\N	\N	152	3836772	79	\N
85	0	55103	16	\N	\N	89	4964650	83	\N
94	0	56184	16	\N	\N	418	4850524	92	\N
114	0	56185	16	\N	\N	120	3732217	113	\N
118	0	56190	16	\N	\N	480	3018275	117	\N
204	0	56176	16	\N	\N	4049	8473200	202	\N
219	0	62910	16	\N	\N	1196	4938611	217	\N
222	0	62911	16	\N	\N	280	5139916	221	\N
240	0	63408	16	\N	\N	199	2754751	239	\N
244	0	68768	16	\N	\N	48	2688105	242	\N
214	1	62909	16	\N	\N	309	6946308	213	\N
280	2	18633	16	1	\N	203	4667646	279	\N
231	1	40452	16	\N	\N	99	3332121	229	\N
227	1	68766	16	\N	\N	831	5313894	224	\N
237	1	63407	16	\N	\N	250	4039019	236	\N
497	0	2526164559	496	1	\N	\N	\N	49	\N
498	0	2526164558	496	1	\N	\N	\N	56	\N
499	0	2526164725	496	\N	\N	\N	\N	73	\N
500	0	2526164726	496	\N	\N	\N	\N	105	\N
501	0	2528311003	496	\N	\N	\N	\N	109	\N
502	0	2528311001	496	\N	\N	\N	\N	153	\N
503	0	2524614720	496	\N	\N	\N	\N	158	\N
504	0	2528311002	496	\N	\N	\N	\N	206	\N
505	0	2528311000	496	\N	\N	\N	\N	209	\N
506	0	2526164727	496	\N	\N	\N	\N	234	\N
507	0	2526164560	496	\N	\N	\N	\N	29	\N
508	0	2526164561	496	\N	\N	\N	\N	36	\N
509	0	2526164562	496	\N	\N	\N	\N	67	\N
510	0	2526164564	496	\N	\N	\N	\N	79	\N
511	0	2526164563	496	\N	\N	\N	\N	83	\N
512	0	2526164565	496	\N	\N	\N	\N	92	\N
513	0	2526164566	496	\N	\N	\N	\N	113	\N
514	0	2526164567	496	\N	\N	\N	\N	117	\N
515	0	2526164568	496	\N	\N	\N	\N	202	\N
516	0	2526164570	496	\N	\N	\N	\N	213	\N
517	0	2526164571	496	\N	\N	\N	\N	217	\N
518	0	2526164569	496	\N	\N	\N	\N	221	\N
519	0	2526164572	496	\N	\N	\N	\N	224	\N
520	0	2526164575	496	\N	\N	\N	\N	229	\N
521	0	2522572152	496	\N	\N	\N	\N	236	\N
522	0	2526164573	496	\N	\N	\N	\N	242	\N
523	0	2526164574	496	\N	\N	\N	\N	239	\N
524	0	89994	16	1	\N	53	2837761	49	\N
525	0	89995	16	1	\N	109	1966916	56	\N
526	0	89996	16	1	\N	142	4445381	73	\N
527	0	89997	16	1	\N	71	3478413	105	\N
528	0	89538	16	1	\N	211	4074318	109	\N
529	0	89543	16	\N	\N	126	2738438	153	\N
530	0	89539	16	\N	\N	53	2837761	158	\N
531	0	89542	16	1	\N	173	5926449	206	\N
532	0	89541	16	1	\N	1007	6362002	209	\N
533	0	89999	16	1	\N	149	2235296	234	\N
\.


--
-- Data for Name: genome_type; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY genome_type (id, version, base_url, organization_name) FROM stdin;
16	0	http://rast.nmpdr.org/rast.cgi?page=JobDetails&job=	Rast
17	0	http://www.ncbi.nlm.nih.gov/bioproject/	NCBI BioProject
496	0	https://img.jgi.doe.gov/cgi-bin/er/main.cgi?section=TaxonDetail&page=taxonDetail&taxon_oid=	IMG
\.


--
-- Data for Name: genus; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY genus (id, version, host, name, phylum_id) FROM stdin;
19	1	t	Danio	18
39	0	f	Pseudomonas	21
48	0	f	Exiguobacterium	47
55	0	f	Haloplasma	54
66	0	f	Acinetobacter	21
72	0	f	Nubsella	71
88	0	f	Chitinibacter	87
91	0	f	Enterobacter	21
97	0	f	Cetobacterium	96
101	0	f	Staphylococcus	47
108	0	f	Vibrio/Listonella	21
112	0	f	Microbacterium	111
116	0	f	Kocuria	111
120	0	f	Comamonas	87
124	0	f	Bacillus	47
127	0	f	Chryseobacterium	71
157	0	f	Vibrio	21
190	0	f	Propionibacterium	111
194	0	f	Dermacoccus	111
201	0	f	Variovorax	87
208	0	f	Delftia	87
212	0	f	Ensifer/Sinorhizobium	211
216	0	f	Bosea	211
233	0	f	Carnobacterium	47
246	0	f	Cellulomonas	111
263	0	f	Enterococcus	47
266	0	f	Proteus	249
282	0	f	Citrobacter	249
287	0	f	Clostridium	47
328	0	f	unclassified Comamonadaceae	87
349	0	f	Shinella	87
359	0	f	Ensifer	211
364	0	f	Mycobacterium	111
537	0	f	unclassified	47
554	0	t	Gasterosteus	18
555	0	f	Pseudomonas a	249
556	0	f	Chromobacterium	249
43	1	f	Shewanella	249
557	0	f	Pseudomonas b	249
558	0	f	Pseuomonas c	249
22	1	f	Plesiomonas	249
559	0	f	Vibrio or Bacillus	249
28	1	f	Aeromonas	249
560	0	f	Lysobacter	249
561	0	f	Oerskovia	111
562	0	f	Serratia	249
563	0	f	Listonella	249
\.


--
-- Data for Name: host_facility; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY host_facility (id, version, name, prefix) FROM stdin;
30	14	University of Oregon	OR
218	1	University of North Carolina	NC
24	2	Washington University	WU
\.


--
-- Data for Name: host_genotype; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY host_genotype (id, version, name, zfin_id) FROM stdin;
31	0	WT	\N
50	0	ABxTu	\N
57	0	ABCxTu	\N
62	0	ABxTu; Tank D from Longitudinal Study 2011	\N
76	0	ABC-7	\N
154	0	ABC-07	\N
\.


--
-- Data for Name: host_origin; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY host_origin (id, version, anatomy, anatomy_url, days_past_fertilization, host_facility_id, notes, species_id, stage, population_id) FROM stdin;
32	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	0	30	\N	20	Larval	\N
51	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	14	30	\N	20	14dpf	\N
672	27	Intestine	\N	180	30	\N	553	6mpf	570
58	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	21	30	\N	20	21dpf	\N
63	2	\N	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	360	30	\N	20	1 year old	\N
68	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	90	30	\N	20	Adult	\N
80	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	28	30	\N	20	28dpf	\N
84	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	6	30	\N	20	6dpf	\N
122	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	12	30	\N	20	12dpf	\N
133	1	\N	\N	4	30	\N	20	4dpf	\N
77	3	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	60	30	\N	20	60dpf	\N
161	2	\N	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	360	30	\N	20	1 year old	\N
872	24	Intestine	\N	90	30	\N	553	Adult	871
164	2	\N	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	360	30	\N	20	1 year old	\N
192	2	\N	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	360	30	\N	20	1 year old	\N
225	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	90	24	\N	20	Adult	\N
130	2	\N	\N	3	30	\N	20	null	\N
731	56	Intestine	\N	90	30	\N	553	Adult	570
571	49	Intestine	\N	35	30	\N	553	35dpf	570
910	6	Intestine	\N	90	30	\N	553	Adult	909
773	16	Intestine	\N	90	30	\N	553	Adult	772
\.


--
-- Data for Name: host_origin_genotypes; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY host_origin_genotypes (host_genotype_id, host_origin_id) FROM stdin;
31	32
50	51
57	58
62	63
31	68
31	80
31	84
31	122
154	77
62	161
62	164
62	192
31	225
\.


--
-- Data for Name: isolate_condition; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY isolate_condition (id, version, isolated_by_id, isolated_when, media, notes, oxygen_condition, temperature) FROM stdin;
33	1	\N	1901-01-01 00:00:00	LB / TSA	null\n	Aerobic	30
41	0	\N	1901-01-01 00:00:00	BHI / LB / TSA	null	Aerobic	30
704	12	545	2011-03-24 00:00:00	ABA	\N	Anaerobic	\N
59	1	3	2013-05-07 00:00:00	BHI+Polymyxin B (1000 units/mL)	null	Aerobic	30
729	1	545	2010-06-03 00:00:00	..	\N	Aerobic	\N
45	2	3	2012-07-09 00:00:00	TSA	null\n	Aerobic	30
734	1	545	2010-06-03 00:00:00	\N	\N	Aerobic	\N
856	1	545	2013-06-25 00:00:00	\N	\N	Aerobic	\N
742	1	545	2010-06-03 00:00:00	\N	\N	Aerobic	\N
103	1	3	2012-07-09 00:00:00	BHI / TSA / NA	null	Anaerobic	30
859	1	545	2013-06-25 00:00:00	\N	\N	Aerobic	\N
750	1	545	2010-06-03 00:00:00	\N	\N	Aerobic	\N
568	22	545	2010-10-21 00:00:00	TSA	\N	Aerobic	\N
864	1	545	2013-06-25 00:00:00	\N	\N	Aerobic	\N
806	10	545	2013-06-25 00:00:00	TSA	\N	Aerobic	\N
762	1	545	2010-06-03 00:00:00	\N	\N	Anaerobic	\N
759	2	545	2010-06-03 00:00:00	TSA	\N	Anaerobic	\N
767	2	545	2010-06-03 00:00:00	LB	\N	Anaerobic	\N
953	1	545	2010-06-30 00:00:00	\N	\N	Aerobic	\N
64	4	3	2013-11-07 00:00:00	BHI+Polymyxin B (1000 units/mL)	null\n\n\n	Anaerobic	30
745	4	545	2010-06-03 00:00:00	LB	\N	Aerobic	\N
782	1	545	2010-06-03 00:00:00	\N	\N	Aerobic	\N
785	1	545	2010-06-03 00:00:00	\N	\N	Aerobic	\N
877	2	545	2013-06-30 00:00:00	TSA/LB	\N	Aerobic	\N
106	8	3	2012-09-11 00:00:00	BHI	null Sonicated gut for 4 min\n Sonicated gut for 4 min\n Sonicated gut for 4 min\n\n\n Sonicated gut for 4 min	Aerobic	30
93	11	3	2011-09-09 00:00:00	NA/M17	null\n\n\n\n\n\n\n\n\n\n	Aerobic	30
226	0	\N	1901-01-01 00:00:00	BHI/LB/TSA	null	Aerobic	30
230	0	\N	1901-01-01 00:00:00	BHI / LB	null	Aerobic	30
25	6	3	1901-01-01 00:00:00	BHI / TSA	null\n\n\n\n	Aerobic	30
99	5	3	1901-01-01 00:00:00	BHI / TSA	null\n\n\n\n	Anaerobic	30
243	0	\N	1901-01-01 00:00:00	BHI / TSA	null	Microaerophilic / Aerobic	30
155	4	3	2013-11-07 00:00:00	Fastidious Anaerobe Agar + 5% Blood	null  	Anaerobic	30
52	8	3	2013-05-07 00:00:00	Fastidious Anaerobe Agar + 5% Blood	null      	Aerobic	30
790	2	545	2010-06-03 00:00:00	TSA/LB	\N	Aerobic	\N
884	1	545	2013-06-30 00:00:00	\N	\N	Aerobic	\N
801	1	545	2010-06-03 00:00:00	\N	\N	Aerobic	\N
616	27	545	2010-10-21 00:00:00	TSA	\N	Anaerobic	\N
737	12	545	2010-06-03 00:00:00	TSA	\N	Aerobic	\N
887	1	545	2013-06-30 00:00:00	\N	\N	Aerobic	\N
812	1	545	2013-06-25 00:00:00	\N	\N	Aerobic	\N
815	1	545	2013-06-25 00:00:00	\N	\N	Aerobic	\N
890	1	545	2013-06-30 00:00:00	\N	\N	Aerobic	\N
671	14	545	2011-03-24 00:00:00	TSA	\N	Aerobic	\N
701	1	545	2011-03-24 00:00:00	Anaerobic blood agar	\N	Anaerobic	\N
893	1	545	2013-06-30 00:00:00	\N	\N	Aerobic	\N
828	1	545	2013-06-25 00:00:00	\N	\N	Aerobic	\N
825	2	545	2013-06-25 00:00:00	TSA/LB	\N	Aerobic	\N
835	1	545	2013-06-25 00:00:00	\N	\N	Aerobic	\N
896	1	545	2013-06-30 00:00:00	\N	\N	Aerobic	\N
950	2	545	2010-06-30 00:00:00	TSA	\N	Aerobic	\N
869	7	545	2013-06-30 00:00:00	TSA	\N	Aerobic	\N
818	7	545	2013-06-25 00:00:00	LB	\N	Aerobic	\N
956	4	545	2010-08-02 00:00:00	LB	\N	Aerobic	\N
907	6	545	2010-07-16 00:00:00	TSA	\N	Aerobic	\N
977	1	545	2010-06-30 00:00:00	\N	\N	Aerobic	\N
980	1	545	2010-06-30 00:00:00	\N	\N	Aerobic	\N
935	1	545	2010-07-07 00:00:00	\N	\N	Aerobic	\N
923	9	545	2010-08-02 00:00:00	TSA	\N	Aerobic	\N
943	2	545	2010-07-07 00:00:00	LB	\N	Aerobic	\N
929	5	545	2010-06-30 00:00:00	LB	\N	Aerobic	\N
\.


--
-- Data for Name: lab; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY lab (id, version, name) FROM stdin;
15	0	Guillemin
539	0	Eisen
1880	0	Cresko
\.


--
-- Data for Name: location; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY location (id, version, name) FROM stdin;
248	57	Rawls -80C Freezer
366	7	Rawls lab -80C freezer
380	1	Rawls Lab -80C Freezer
382	4	Rawls lab -80C
27	66	Guillemin -80 C Freezer
\.


--
-- Data for Name: measured_value; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY measured_value (id, version, category_id, experiment_id, strain_id, type, value) FROM stdin;
400	0	390	391	29	TEXT	motile
401	0	392	393	29	TEXT	Beta Hemolysis
402	0	394	395	29	TEXT	Kan resistant(100ug/ml)
403	0	396	397	29	TEXT	24.38
404	0	398	399	29	TEXT	-
406	0	390	391	36	TEXT	motile
407	0	392	393	36	TEXT	Beta Hemolysis
408	0	394	395	36	TEXT	Kan resistant(100ug/ml), Rif sensitive(100ug/ml), Gn sensitive (110ug/ml), CAM sensitive (10ug/ml), TC sensitive (100ug/ml)
409	0	396	397	36	TEXT	23.03
410	0	398	399	36	TEXT	-
411	0	394	395	56	TEXT	Polymyxin B resistant (1000 units/mL)
412	0	394	395	61	TEXT	Polymyxin B resistant (1000 units/mL)
413	0	390	391	67	TEXT	motile (twitch)
414	0	392	393	67	TEXT	Beta Hemolysis
415	0	394	395	67	TEXT	Rif Sens. (100 ug/mL-ZS); Kan Sens. (50 ug/mL-ZS); Trimethoprim Resist. (100 ug/mL-ZS); Chloramphenicol Resist. (20 ug/mL-ZS); Gentamycin Sens. (10 ug/mL - ZS)
416	0	396	397	67	TEXT	24.92
417	0	398	399	67	TEXT	+
418	0	394	395	73	TEXT	Polymyxin B resistant (1000 units/mL)
419	0	390	391	79	TEXT	motile
420	0	392	393	79	TEXT	Beta hemolysis
421	0	394	395	79	TEXT	Kan Sensitive (100ug/ml)
422	0	396	397	79	TEXT	27.32
423	0	398	399	79	TEXT	+
424	0	390	391	83	TEXT	motile
425	0	392	393	83	TEXT	Beta Hemolysis
426	0	394	395	83	TEXT	Rif Sens. (100 ug/mL-ZS); Kan Sens. (50 ug/mL-ZS); Kan Sens. (100 ug/mL - ZS); Trimethoprim Sens. (100 ug/mL-ZS); Chloramphenicol Sens. (20 ug/mL-ZS); Gentamycin Sens. (10 ug/mL - ZS)
427	0	396	397	83	TEXT	30.62
428	0	398	399	83	TEXT	+
429	0	390	391	92	TEXT	motile
430	0	392	393	92	TEXT	Beta Hemolysis
431	0	394	395	92	TEXT	Kan Sensitive (100ug/ml), Rif sensitive(100ug/ml), Gn sensitive (110ug/ml), CAM sensitive (10ug/ml), TC resistant (100ug/ml)
432	0	396	397	92	TEXT	30.58
433	0	398	399	92	TEXT	+
434	0	390	391	102	TEXT	non-motile
435	0	392	393	102	TEXT	Beta Hemolysis and alpha hemolysis (in oxygen labile pocket)
436	0	390	391	105	TEXT	motile
437	0	392	393	105	TEXT	(in oxygen labile pocket) alpha hemolysis
438	0	396	397	105	TEXT	31.53
439	0	398	399	105	TEXT	+
440	0	390	391	109	TEXT	motile
441	0	392	393	109	TEXT	Beta Hemolysis
442	0	390	391	113	TEXT	non-motile
443	0	392	393	113	TEXT	Beta Hemolysis
444	0	394	395	113	TEXT	Rif Sens. (100 ug/mL-ZS); Kan Resist. (50 ug/mL-ZS); Kan Sens. (100 ug/mL - ZS); Trimethoprim Sens. (100 ug/mL-ZS); Chloramphenicol Sens. (20 ug/mL = some growth, 40 ug/mL = NO growth after 2 days-ZS); Gentamycin Resist. (10 ug/mL - ZS)
445	0	396	397	113	TEXT	38.04
446	0	398	399	113	TEXT	-
447	0	390	391	117	TEXT	non-motile
448	0	392	393	117	TEXT	Beta Hemolysis and alpha hemolysis (in oxygen labile pocket)
449	0	398	399	117	TEXT	+
450	0	394	395	163	TEXT	Polymyxin B resistant (1000 units/mL)
451	0	394	395	166	TEXT	Polymyxin B resistant (1000 units/mL)
452	0	392	393	188	TEXT	Beta Hemolysis
453	0	390	391	202	TEXT	motile
454	0	392	393	202	TEXT	Gamma (non-hemolytic)
455	0	396	397	202	TEXT	37.17
456	0	398	399	202	TEXT	+
457	0	390	391	206	TEXT	motile
458	0	392	393	206	TEXT	Gamma (non-hemolytic)
459	0	396	397	206	TEXT	34.22
460	0	398	399	206	TEXT	+
461	0	390	391	209	TEXT	motile
462	0	392	393	209	TEXT	Gamma (non-hemolytic)
463	0	396	397	209	TEXT	30.74
464	0	398	399	209	TEXT	+
465	0	390	391	213	TEXT	motile
466	0	392	393	213	TEXT	Gamma (non-hemolytic)
467	0	396	397	213	TEXT	33.45
468	0	398	399	213	TEXT	+
469	0	390	391	217	TEXT	non-motile
470	0	392	393	217	TEXT	Gamma (non-hemolytic)
471	0	396	397	217	TEXT	30.09
472	0	398	399	217	TEXT	+
473	0	390	391	221	TEXT	motile
474	0	392	393	221	TEXT	Gamma (non-hemolytic)
475	0	394	395	221	TEXT	Kan resistant(100ug/ml)
476	0	396	397	221	TEXT	27.05
477	0	398	399	221	TEXT	+
478	0	390	391	224	TEXT	motile
479	0	392	393	224	TEXT	Gamma (non-hemolytic)
480	0	396	397	224	TEXT	32.83
481	0	398	399	224	TEXT	-
482	0	390	391	229	TEXT	motile
483	0	392	393	229	TEXT	Gamma (non-hemolytic)
484	0	396	397	229	TEXT	26.56
485	0	398	399	229	TEXT	+
486	0	390	391	234	TEXT	non-motile
487	0	392	393	234	TEXT	Gamma (non-hemolytic)
488	0	396	397	234	TEXT	47.74 (?)
489	0	398	399	234	TEXT	-
490	0	390	391	236	TEXT	motile
491	0	392	393	236	TEXT	Beta Hemolysis (Aerobic and in oxygen labile pocket)
492	0	394	395	236	TEXT	Kan sensitive(100ug/ml)
493	0	396	397	236	TEXT	30.96
494	0	398	399	236	TEXT	-
990	0	985	569	566	TEXT	small, 0.3mm
991	0	986	569	566	TEXT	yellow
992	0	987	569	566	TEXT	smooth entire
993	0	988	569	566	TEXT	y
994	0	989	569	566	TEXT	Round
995	0	985	569	572	TEXT	small 1mm
996	0	986	569	572	TEXT	yellow-orange
997	0	987	569	572	TEXT	entire
998	0	988	569	572	TEXT	y
999	0	989	569	572	TEXT	Round
1000	0	985	569	574	TEXT	small 1mm
1001	0	986	569	574	TEXT	buff
1002	0	987	569	574	TEXT	entire
1003	0	988	569	574	TEXT	y
1004	0	989	569	574	TEXT	Round
1005	0	985	569	576	TEXT	1-2mm
1006	0	986	569	576	TEXT	buff
1007	0	987	569	576	TEXT	entire
1008	0	988	569	576	TEXT	convex
1009	0	989	569	576	TEXT	Round
1010	0	985	569	578	TEXT	2mm
1011	0	986	569	578	TEXT	buff
1012	0	987	569	578	TEXT	entire
1013	0	988	569	578	TEXT	flat
1014	0	989	569	578	TEXT	Round
1015	0	985	569	580	TEXT	2mm
1016	0	986	569	580	TEXT	buff
1017	0	987	569	580	TEXT	undulate
1018	0	988	569	580	TEXT	flat
1019	0	989	569	580	TEXT	Round
1020	0	985	569	582	TEXT	4mm
1021	0	986	569	582	TEXT	buff
1022	0	987	569	582	TEXT	entire
1023	0	988	569	582	TEXT	Raised
1024	0	989	569	582	TEXT	Round
1025	0	985	569	584	TEXT	3-4mm
1026	0	986	569	584	TEXT	transparent
1027	0	987	569	584	TEXT	entire/ undulate
1028	0	988	569	584	TEXT	Raised
1029	0	989	569	584	TEXT	Round
1030	0	985	569	586	TEXT	3-4mm
1031	0	986	569	586	TEXT	buff
1032	0	987	569	586	TEXT	entire/ undulate
1033	0	988	569	586	TEXT	Raised
1034	0	989	569	586	TEXT	Round
1035	0	985	569	588	TEXT	2mm
1036	0	986	569	588	TEXT	white
1037	0	987	569	588	TEXT	undulate
1038	0	988	569	588	TEXT	flat
1039	0	989	569	588	TEXT	irregular
1040	0	985	569	590	TEXT	2.5mm
1041	0	986	569	590	TEXT	pinkish/ salmon
1042	0	987	569	590	TEXT	entire
1043	0	988	569	590	TEXT	Raised
1044	0	989	569	590	TEXT	Round
1045	0	985	569	592	TEXT	0.3mm
1046	0	986	569	592	TEXT	transparent
1047	0	987	569	592	TEXT	entire
1048	0	988	569	592	TEXT	Raised?
1049	0	989	569	592	TEXT	Round
1050	0	985	569	594	TEXT	2mm
1051	0	986	569	594	TEXT	orangish/ salmon/buff
1052	0	987	569	594	TEXT	entire
1053	0	988	569	594	TEXT	Raised
1054	0	989	569	594	TEXT	Round
1055	0	985	569	596	TEXT	4mm
1056	0	986	569	596	TEXT	salmon
1057	0	987	569	596	TEXT	entire
1058	0	988	569	596	TEXT	Raised
1059	0	989	569	596	TEXT	Round
1060	0	985	569	598	TEXT	5mm
1061	0	986	569	598	TEXT	cream
1062	0	987	569	598	TEXT	entire
1063	0	988	569	598	TEXT	Riased
1064	0	989	569	598	TEXT	Round
1065	0	985	569	600	TEXT	3mm
1066	0	986	569	600	TEXT	yellow
1067	0	987	569	600	TEXT	flat
1068	0	988	569	600	TEXT	form
1069	0	989	569	600	TEXT	Round
1070	0	985	569	602	TEXT	3mm
1071	0	986	569	602	TEXT	salmon
1072	0	987	569	602	TEXT	entire
1073	0	988	569	602	TEXT	Raised
1074	0	989	569	602	TEXT	Round
1075	0	985	569	604	TEXT	0.5mm
1076	0	986	569	604	TEXT	transparent
1077	0	987	569	604	TEXT	entire
1078	0	988	569	604	TEXT	Raised
1079	0	989	569	604	TEXT	Round
1080	0	985	569	606	TEXT	2-5mm
1081	0	986	569	606	TEXT	yellow/ transparent
1082	0	987	569	606	TEXT	undulate
1083	0	988	569	606	TEXT	Undulate
1084	0	989	569	606	TEXT	Round
1085	0	985	569	608	TEXT	
1086	0	986	569	608	TEXT	transparent edges, buff center
1087	0	987	569	608	TEXT	lobate
1088	0	988	569	608	TEXT	convex
1089	0	989	569	608	TEXT	Round/ irregular
1090	0	985	569	610	TEXT	1.5mm
1091	0	986	569	610	TEXT	transparent edges buff center
1092	0	987	569	610	TEXT	undulate
1093	0	988	569	610	TEXT	riased center
1094	0	989	569	610	TEXT	Round
1095	0	985	569	612	TEXT	1.5mm
1096	0	986	569	612	TEXT	transparent
1097	0	987	569	612	TEXT	undulate
1098	0	988	569	612	TEXT	raised center flat edges
1099	0	989	569	612	TEXT	Round
1100	0	985	569	614	TEXT	7.5mm
1101	0	986	569	614	TEXT	translucent, yellow
1102	0	987	569	614	TEXT	slightly wavy, undulate
1103	0	988	569	614	TEXT	flat
1104	0	989	569	614	TEXT	circular
1105	0	985	569	617	TEXT	4mm
1106	0	986	569	617	TEXT	buff
1107	0	987	569	617	TEXT	entire
1108	0	988	569	617	TEXT	flat
1109	0	989	569	617	TEXT	circular
1110	0	985	569	619	TEXT	3mm
1111	0	986	569	619	TEXT	buff, translucent
1112	0	987	569	619	TEXT	entire
1113	0	988	569	619	TEXT	raised
1114	0	989	569	619	TEXT	circular
1115	0	985	569	621	TEXT	5mm
1116	0	986	569	621	TEXT	buff
1117	0	987	569	621	TEXT	undulate
1118	0	988	569	621	TEXT	flat
1119	0	989	569	621	TEXT	irregular, circular
1120	0	985	569	623	TEXT	1mm
1121	0	986	569	623	TEXT	buff
1122	0	987	569	623	TEXT	entire
1123	0	988	569	623	TEXT	flat
1124	0	989	569	623	TEXT	
1125	0	985	569	625	TEXT	1.5mm
1126	0	986	569	625	TEXT	transparent
1127	0	987	569	625	TEXT	entire
1128	0	988	569	625	TEXT	flat
1129	0	989	569	625	TEXT	circular
1130	0	985	569	627	TEXT	0.5mm
1131	0	986	569	627	TEXT	translucent, buff
1132	0	987	569	627	TEXT	entire
1133	0	988	569	627	TEXT	raised
1134	0	989	569	627	TEXT	circular
1135	0	985	569	629	TEXT	1mm
1136	0	986	569	629	TEXT	transparent, buff
1137	0	987	569	629	TEXT	filiform
1138	0	988	569	629	TEXT	flat
1139	0	989	569	629	TEXT	irregular, circular
1140	0	985	569	631	TEXT	1mm
1141	0	986	569	631	TEXT	buff
1142	0	987	569	631	TEXT	entire
1143	0	988	569	631	TEXT	flat/raise
1144	0	989	569	631	TEXT	circular
1145	0	985	569	633	TEXT	2mm
1146	0	986	569	633	TEXT	transparent
1147	0	987	569	633	TEXT	entire
1148	0	988	569	633	TEXT	flat
1149	0	989	569	633	TEXT	circular
1150	0	985	569	635	TEXT	4mm
1151	0	986	569	635	TEXT	edges tranparnet, center buff
1152	0	987	569	635	TEXT	entire
1153	0	988	569	635	TEXT	umbonate
1154	0	989	569	635	TEXT	circle/wavy
1155	0	985	569	637	TEXT	4mm
1156	0	986	569	637	TEXT	translucent, buff
1157	0	987	569	637	TEXT	entire
1158	0	988	569	637	TEXT	flat
1159	0	989	569	637	TEXT	circular
1160	0	985	569	639	TEXT	3mm
1161	0	986	569	639	TEXT	buff
1162	0	987	569	639	TEXT	entire
1163	0	988	569	639	TEXT	raised
1164	0	989	569	639	TEXT	irregular/circle
1165	0	985	569	641	TEXT	half of plate
1166	0	986	569	641	TEXT	translucent
1167	0	987	569	641	TEXT	lobate
1168	0	988	569	641	TEXT	flat
1169	0	989	569	641	TEXT	irregular
1170	0	985	569	643	TEXT	1mm
1171	0	986	569	643	TEXT	buff
1172	0	987	569	643	TEXT	enture
1173	0	988	569	643	TEXT	?
1174	0	989	569	643	TEXT	irregular or cicular
1175	0	985	569	645	TEXT	1mm
1176	0	986	569	645	TEXT	translucent
1177	0	987	569	645	TEXT	entire
1178	0	988	569	645	TEXT	convex?
1179	0	989	569	645	TEXT	circular
1180	0	985	569	647	TEXT	3mm
1181	0	986	569	647	TEXT	translucent
1182	0	987	569	647	TEXT	undulate
1183	0	988	569	647	TEXT	raised
1184	0	989	569	647	TEXT	circular
1185	0	985	569	649	TEXT	1mm
1186	0	986	569	649	TEXT	buff, edges lighter
1187	0	987	569	649	TEXT	undulate
1188	0	988	569	649	TEXT	flat
1189	0	989	569	649	TEXT	circular
1190	0	985	569	651	TEXT	1/4 to 1/5 of plate
1191	0	986	569	651	TEXT	translucent
1192	0	987	569	651	TEXT	lobate
1193	0	988	569	651	TEXT	flat
1194	0	989	569	651	TEXT	rhizoid
1195	0	985	569	653	TEXT	3mm
1196	0	986	569	653	TEXT	white
1197	0	987	569	653	TEXT	entire
1198	0	988	569	653	TEXT	raised
1199	0	989	569	653	TEXT	circular
1200	0	985	569	655	TEXT	0.3mm
1201	0	986	569	655	TEXT	translucent
1202	0	987	569	655	TEXT	entire
1203	0	988	569	655	TEXT	flat/concave
1204	0	989	569	655	TEXT	circular
1205	0	985	569	657	TEXT	2mm
1206	0	986	569	657	TEXT	transparent
1207	0	987	569	657	TEXT	undulate
1208	0	988	569	657	TEXT	concave
1209	0	989	569	657	TEXT	irregular
1210	0	985	569	659	TEXT	2mm
1211	0	986	569	659	TEXT	center translucent, edge transparent
1212	0	987	569	659	TEXT	lobate
1213	0	988	569	659	TEXT	concave in center
1214	0	989	569	659	TEXT	center circle, edge irregular
1215	0	985	569	661	TEXT	2mm
1216	0	986	569	661	TEXT	transparent edge, translucent center
1217	0	987	569	661	TEXT	entire
1218	0	988	569	661	TEXT	riased center
1219	0	989	569	661	TEXT	circular
1220	0	985	569	663	TEXT	2mm
1221	0	986	569	663	TEXT	transparent
1222	0	987	569	663	TEXT	undulate
1223	0	988	569	663	TEXT	flat
1224	0	989	569	663	TEXT	circular
1225	0	985	569	665	TEXT	2mm
1226	0	986	569	665	TEXT	transparent
1227	0	987	569	665	TEXT	undulate
1228	0	988	569	665	TEXT	flat
1229	0	989	569	665	TEXT	irregular
1230	0	985	569	667	TEXT	2mm
1231	0	986	569	667	TEXT	buff, ringed
1232	0	987	569	667	TEXT	entire
1233	0	988	569	667	TEXT	riased center
1234	0	989	569	667	TEXT	cicular
1235	0	985	569	669	TEXT	1.5-3
1236	0	986	569	669	TEXT	white matte
1237	0	987	569	669	TEXT	entire
1238	0	988	569	669	TEXT	convex
1239	0	989	569	669	TEXT	round
1240	0	985	569	673	TEXT	3
1241	0	986	569	673	TEXT	white matte
1242	0	987	569	673	TEXT	undulate
1243	0	988	569	673	TEXT	flat
1244	0	989	569	673	TEXT	round
1245	0	985	569	675	TEXT	2
1246	0	986	569	675	TEXT	shiny orange
1247	0	987	569	675	TEXT	entire
1248	0	988	569	675	TEXT	convex
1249	0	989	569	675	TEXT	round
1250	0	985	569	677	TEXT	2
1251	0	986	569	677	TEXT	shiny yellow
1252	0	987	569	677	TEXT	entire
1253	0	988	569	677	TEXT	Raised?
1254	0	989	569	677	TEXT	round
1255	0	985	569	679	TEXT	1
1256	0	986	569	679	TEXT	clear yellow
1257	0	987	569	679	TEXT	entire
1258	0	988	569	679	TEXT	convex
1259	0	989	569	679	TEXT	round
1260	0	985	569	681	TEXT	1.5
1261	0	986	569	681	TEXT	opaque white
1262	0	987	569	681	TEXT	entire
1263	0	988	569	681	TEXT	convex
1264	0	989	569	681	TEXT	round
1265	0	985	569	683	TEXT	1-1.5
1266	0	986	569	683	TEXT	white/buff shiny
1267	0	987	569	683	TEXT	entire
1268	0	988	569	683	TEXT	convex
1269	0	989	569	683	TEXT	round
1270	0	985	569	685	TEXT	2.5
1271	0	986	569	685	TEXT	buff shiny
1272	0	987	569	685	TEXT	entire
1273	0	988	569	685	TEXT	convex
1274	0	989	569	685	TEXT	round
1275	0	985	569	687	TEXT	1
1276	0	986	569	687	TEXT	flat grey
1277	0	987	569	687	TEXT	entire-undulate
1278	0	988	569	687	TEXT	flat
1279	0	989	569	687	TEXT	round
1280	0	985	569	689	TEXT	pin-point
1281	0	986	569	689	TEXT	tiny whitish
1282	0	987	569	689	TEXT	entire
1283	0	988	569	689	TEXT	convex
1284	0	989	569	689	TEXT	round
1285	0	985	569	691	TEXT	pin point
1286	0	986	569	691	TEXT	tiny whitish
1287	0	987	569	691	TEXT	entire
1288	0	988	569	691	TEXT	convex
1289	0	989	569	691	TEXT	round
1290	0	985	569	693	TEXT	pin-point
1291	0	986	569	693	TEXT	tiny yellow
1292	0	987	569	693	TEXT	entire
1293	0	988	569	693	TEXT	convex
1294	0	989	569	693	TEXT	round
1295	0	985	569	695	TEXT	2
1296	0	986	569	695	TEXT	white matte
1297	0	987	569	695	TEXT	undulate
1298	0	988	569	695	TEXT	umbonate
1299	0	989	569	695	TEXT	round
1300	0	985	569	697	TEXT	2
1301	0	986	569	697	TEXT	yellow
1302	0	987	569	697	TEXT	undulate
1303	0	988	569	697	TEXT	raised
1304	0	989	569	697	TEXT	round
1305	0	985	569	699	TEXT	2
1306	0	986	569	699	TEXT	white/grey
1307	0	987	569	699	TEXT	entire/ undulate
1308	0	988	569	699	TEXT	convex
1309	0	989	569	699	TEXT	circular/irregular
1310	0	985	569	702	TEXT	3
1311	0	986	569	702	TEXT	clear
1312	0	987	569	702	TEXT	entire/ undulate
1313	0	988	569	702	TEXT	flat
1314	0	989	569	702	TEXT	circular
1315	0	985	569	705	TEXT	4-5
1316	0	986	569	705	TEXT	white
1317	0	987	569	705	TEXT	lobate
1318	0	988	569	705	TEXT	Raised?
1319	0	989	569	705	TEXT	irregular
1320	0	985	569	707	TEXT	1
1321	0	986	569	707	TEXT	grey/clear
1322	0	987	569	707	TEXT	entire
1323	0	988	569	707	TEXT	crateri form
1324	0	989	569	707	TEXT	circular
1325	0	985	569	709	TEXT	2
1326	0	986	569	709	TEXT	grey
1327	0	987	569	709	TEXT	undulate
1328	0	988	569	709	TEXT	Raised?
1329	0	989	569	709	TEXT	mostly circular but irregular
1330	0	985	569	711	TEXT	0.5-1
1331	0	986	569	711	TEXT	white
1332	0	987	569	711	TEXT	entire
1333	0	988	569	711	TEXT	convex
1334	0	989	569	711	TEXT	circular
1335	0	985	569	713	TEXT	1
1336	0	986	569	713	TEXT	grey center, clear edges
1337	0	987	569	713	TEXT	undulate
1338	0	988	569	713	TEXT	umbonate
1339	0	989	569	713	TEXT	irregular
1340	0	985	569	715	TEXT	2
1341	0	986	569	715	TEXT	grey center, clear edges
1342	0	987	569	715	TEXT	entire
1343	0	988	569	715	TEXT	flat
1344	0	989	569	715	TEXT	circular
1345	0	985	569	717	TEXT	pin-point
1346	0	986	569	717	TEXT	-
1347	0	987	569	717	TEXT	entire
1348	0	988	569	717	TEXT	?
1349	0	989	569	717	TEXT	circular
1350	0	985	569	719	TEXT	7
1351	0	986	569	719	TEXT	white
1352	0	987	569	719	TEXT	undulate/entire
1353	0	988	569	719	TEXT	umbonate
1354	0	989	569	719	TEXT	circular/irregular
1355	0	985	569	721	TEXT	2
1356	0	986	569	721	TEXT	clear
1357	0	987	569	721	TEXT	entire
1358	0	988	569	721	TEXT	flat
1359	0	989	569	721	TEXT	circular
1360	0	985	569	723	TEXT	3-5
1361	0	986	569	723	TEXT	grey
1362	0	987	569	723	TEXT	entire
1363	0	988	569	723	TEXT	raise, fmall, flat large
1364	0	989	569	723	TEXT	circular
1365	0	985	569	725	TEXT	2
1366	0	986	569	725	TEXT	white
1367	0	987	569	725	TEXT	entire
1368	0	988	569	725	TEXT	convex
1369	0	989	569	725	TEXT	circular
1370	0	985	730	727	TEXT	
1371	0	986	730	727	TEXT	White
1372	0	987	730	727	TEXT	entire
1373	0	988	730	727	TEXT	raised
1374	0	989	730	727	TEXT	circular
1375	0	985	730	732	TEXT	punctiform
1376	0	986	730	732	TEXT	yellow
1377	0	987	730	732	TEXT	entire
1378	0	988	730	732	TEXT	flat
1379	0	989	730	732	TEXT	circular
1380	0	985	730	735	TEXT	punctiform
1381	0	986	730	735	TEXT	yellow
1382	0	987	730	735	TEXT	entire
1383	0	988	730	735	TEXT	flat
1384	0	989	730	735	TEXT	circular
1385	0	985	730	738	TEXT	punctiform
1386	0	986	730	738	TEXT	white
1387	0	987	730	738	TEXT	entire
1388	0	988	730	738	TEXT	flat
1389	0	989	730	738	TEXT	circular
1390	0	985	730	740	TEXT	
1391	0	986	730	740	TEXT	orangish/ salmon/buff
1392	0	987	730	740	TEXT	undulate
1393	0	988	730	740	TEXT	convex
1394	0	989	730	740	TEXT	circular
1395	0	985	730	743	TEXT	
1396	0	986	730	743	TEXT	yellow
1397	0	987	730	743	TEXT	
1398	0	988	730	743	TEXT	
1399	0	989	730	743	TEXT	circular
1400	0	985	730	746	TEXT	
1401	0	986	730	746	TEXT	white
1402	0	987	730	746	TEXT	
1403	0	988	730	746	TEXT	
1404	0	989	730	746	TEXT	circular
1405	0	985	730	748	TEXT	punctiform
1406	0	986	730	748	TEXT	cream
1407	0	987	730	748	TEXT	entire
1408	0	988	730	748	TEXT	flat
1409	0	989	730	748	TEXT	circular
1410	0	985	730	751	TEXT	punctiform
1411	0	986	730	751	TEXT	yellow
1412	0	987	730	751	TEXT	
1413	0	988	730	751	TEXT	
1414	0	989	730	751	TEXT	circular
1415	0	985	730	753	TEXT	punctiform
1416	0	986	730	753	TEXT	white
1417	0	987	730	753	TEXT	
1418	0	988	730	753	TEXT	
1419	0	989	730	753	TEXT	circular
1420	0	985	730	755	TEXT	punctiform
1421	0	986	730	755	TEXT	white
1422	0	987	730	755	TEXT	entire
1423	0	988	730	755	TEXT	convex
1424	0	989	730	755	TEXT	circular
1425	0	985	730	757	TEXT	
1426	0	986	730	757	TEXT	pinkish/ salmon
1427	0	987	730	757	TEXT	entire
1428	0	988	730	757	TEXT	convex
1429	0	989	730	757	TEXT	circular
1430	0	985	730	760	TEXT	punctiform
1431	0	986	730	760	TEXT	white
1432	0	987	730	760	TEXT	entire
1433	0	988	730	760	TEXT	raised
1434	0	989	730	760	TEXT	circular
1435	0	985	730	763	TEXT	large
1436	0	986	730	763	TEXT	
1437	0	987	730	763	TEXT	
1438	0	988	730	763	TEXT	
1439	0	989	730	763	TEXT	circular
1440	0	985	730	765	TEXT	punctiform
1441	0	986	730	765	TEXT	
1442	0	987	730	765	TEXT	
1443	0	988	730	765	TEXT	
1444	0	989	730	765	TEXT	circular
1445	0	985	730	768	TEXT	punctiform
1446	0	986	730	768	TEXT	white
1447	0	987	730	768	TEXT	entire
1448	0	988	730	768	TEXT	raised
1449	0	989	730	768	TEXT	circular or irregular
1450	0	985	730	770	TEXT	
1451	0	986	730	770	TEXT	white
1452	0	987	730	770	TEXT	filiform
1453	0	988	730	770	TEXT	pulvinate
1454	0	989	730	770	TEXT	irregular
1455	0	985	730	774	TEXT	punctiform
1456	0	986	730	774	TEXT	yellow
1457	0	987	730	774	TEXT	circular to irregular
1458	0	988	730	774	TEXT	umbunate
1459	0	989	730	774	TEXT	fuzzy
1460	0	985	730	776	TEXT	punctiform
1461	0	986	730	776	TEXT	
1462	0	987	730	776	TEXT	entire
1463	0	988	730	776	TEXT	raised
1464	0	989	730	776	TEXT	circular
1465	0	985	730	778	TEXT	
1466	0	986	730	778	TEXT	white
1467	0	987	730	778	TEXT	slightly fluted
1468	0	988	730	778	TEXT	raised
1469	0	989	730	778	TEXT	circular
1470	0	985	730	780	TEXT	punctiform
1471	0	986	730	780	TEXT	transparent
1472	0	987	730	780	TEXT	entire
1473	0	988	730	780	TEXT	convex
1474	0	989	730	780	TEXT	circular
1475	0	985	730	783	TEXT	punctiform
1476	0	986	730	783	TEXT	
1477	0	987	730	783	TEXT	
1478	0	988	730	783	TEXT	
1479	0	989	730	783	TEXT	
1480	0	985	730	786	TEXT	medium
1481	0	986	730	786	TEXT	
1482	0	987	730	786	TEXT	
1483	0	988	730	786	TEXT	
1484	0	989	730	786	TEXT	
1485	0	985	730	788	TEXT	
1486	0	986	730	788	TEXT	cream
1487	0	987	730	788	TEXT	entire
1488	0	988	730	788	TEXT	raised
1489	0	989	730	788	TEXT	circular
1490	0	985	730	791	TEXT	punctiform
1491	0	986	730	791	TEXT	white
1492	0	987	730	791	TEXT	entire
1493	0	988	730	791	TEXT	raised
1494	0	989	730	791	TEXT	circular
1495	0	985	730	793	TEXT	
1496	0	986	730	793	TEXT	cream
1497	0	987	730	793	TEXT	entire
1498	0	988	730	793	TEXT	raised
1499	0	989	730	793	TEXT	circular
1500	0	985	730	795	TEXT	punctiform
1501	0	986	730	795	TEXT	yellow
1502	0	987	730	795	TEXT	filiform
1503	0	988	730	795	TEXT	umbonate
1504	0	989	730	795	TEXT	circular
1505	0	985	730	797	TEXT	punctiform
1506	0	986	730	797	TEXT	
1507	0	987	730	797	TEXT	entire
1508	0	988	730	797	TEXT	flat
1509	0	989	730	797	TEXT	circular
1510	0	985	730	799	TEXT	punctiform
1511	0	986	730	799	TEXT	colorless
1512	0	987	730	799	TEXT	slightly fluted
1513	0	988	730	799	TEXT	flat
1514	0	989	730	799	TEXT	circular
1515	0	985	730	802	TEXT	punctiform
1516	0	986	730	802	TEXT	yellow
1517	0	987	730	802	TEXT	filiform
1518	0	988	730	802	TEXT	umbonate
1519	0	989	730	802	TEXT	circular
1520	0	985	807	804	TEXT	
1521	0	986	807	804	TEXT	White
1522	0	987	807	804	TEXT	entire
1523	0	988	807	804	TEXT	raised
1524	0	989	807	804	TEXT	circular
1525	0	985	807	808	TEXT	
1526	0	986	807	808	TEXT	White
1527	0	987	807	808	TEXT	entire
1528	0	988	807	808	TEXT	raised
1529	0	989	807	808	TEXT	circular
1530	0	985	807	810	TEXT	Small
1531	0	986	807	810	TEXT	colorless
1532	0	987	807	810	TEXT	
1533	0	988	807	810	TEXT	
1534	0	989	807	810	TEXT	Circular
1535	0	985	807	813	TEXT	Small
1536	0	986	807	813	TEXT	colorless
1537	0	987	807	813	TEXT	
1538	0	988	807	813	TEXT	
1539	0	989	807	813	TEXT	Circular
1540	0	985	807	816	TEXT	Small
1541	0	986	807	816	TEXT	White
1542	0	987	807	816	TEXT	entire
1543	0	988	807	816	TEXT	raised
1544	0	989	807	816	TEXT	circular
1545	0	985	807	819	TEXT	Small
1546	0	986	807	819	TEXT	White
1547	0	987	807	819	TEXT	entire
1548	0	988	807	819	TEXT	raised
1549	0	989	807	819	TEXT	circular
1550	0	985	807	821	TEXT	
1551	0	986	807	821	TEXT	pinkish/ salmon
1552	0	987	807	821	TEXT	entire
1553	0	988	807	821	TEXT	convex
1554	0	989	807	821	TEXT	circular
1555	0	985	807	823	TEXT	
1556	0	986	807	823	TEXT	pinkish/ salmon
1557	0	987	807	823	TEXT	entire
1558	0	988	807	823	TEXT	convex
1559	0	989	807	823	TEXT	circular
1560	0	985	807	826	TEXT	
1561	0	986	807	826	TEXT	Orange
1562	0	987	807	826	TEXT	
1563	0	988	807	826	TEXT	
1564	0	989	807	826	TEXT	irregular
1565	0	985	807	829	TEXT	
1566	0	986	807	829	TEXT	
1567	0	987	807	829	TEXT	
1568	0	988	807	829	TEXT	
1569	0	989	807	829	TEXT	
1570	0	985	807	831	TEXT	
1571	0	986	807	831	TEXT	
1572	0	987	807	831	TEXT	
1573	0	988	807	831	TEXT	
1574	0	989	807	831	TEXT	
1575	0	985	807	833	TEXT	
1576	0	986	807	833	TEXT	Orange
1577	0	987	807	833	TEXT	
1578	0	988	807	833	TEXT	
1579	0	989	807	833	TEXT	irregular
1580	0	985	807	836	TEXT	
1581	0	986	807	836	TEXT	
1582	0	987	807	836	TEXT	
1583	0	988	807	836	TEXT	
1584	0	989	807	836	TEXT	
1585	0	985	807	838	TEXT	
1586	0	986	807	838	TEXT	
1587	0	987	807	838	TEXT	
1588	0	988	807	838	TEXT	
1589	0	989	807	838	TEXT	
1590	0	985	807	840	TEXT	very large
1591	0	986	807	840	TEXT	
1592	0	987	807	840	TEXT	
1593	0	988	807	840	TEXT	
1594	0	989	807	840	TEXT	irregular
1595	0	985	807	842	TEXT	very large
1596	0	986	807	842	TEXT	
1597	0	987	807	842	TEXT	
1598	0	988	807	842	TEXT	
1599	0	989	807	842	TEXT	irregular
1600	0	985	807	844	TEXT	small
1601	0	986	807	844	TEXT	white
1602	0	987	807	844	TEXT	
1603	0	988	807	844	TEXT	
1604	0	989	807	844	TEXT	
1605	0	985	807	846	TEXT	small
1606	0	986	807	846	TEXT	white
1607	0	987	807	846	TEXT	
1608	0	988	807	846	TEXT	
1609	0	989	807	846	TEXT	
1610	0	985	807	848	TEXT	
1611	0	986	807	848	TEXT	yellow-orange-brown
1612	0	987	807	848	TEXT	
1613	0	988	807	848	TEXT	
1614	0	989	807	848	TEXT	circular
1615	0	985	807	850	TEXT	
1616	0	986	807	850	TEXT	yellow-orange-brown
1617	0	987	807	850	TEXT	
1618	0	988	807	850	TEXT	
1619	0	989	807	850	TEXT	circular
1620	0	985	807	852	TEXT	very small
1621	0	986	807	852	TEXT	colorless
1622	0	987	807	852	TEXT	slightly fluted
1623	0	988	807	852	TEXT	flat
1624	0	989	807	852	TEXT	circular
1625	0	985	807	854	TEXT	very small
1626	0	986	807	854	TEXT	colorless
1627	0	987	807	854	TEXT	slightly fluted
1628	0	988	807	854	TEXT	flat
1629	0	989	807	854	TEXT	circular
1630	0	985	807	857	TEXT	
1631	0	986	807	857	TEXT	light yellow-brown
1632	0	987	807	857	TEXT	
1633	0	988	807	857	TEXT	
1634	0	989	807	857	TEXT	irregular
1635	0	985	807	860	TEXT	
1636	0	986	807	860	TEXT	light yellow-brown
1637	0	987	807	860	TEXT	
1638	0	988	807	860	TEXT	
1639	0	989	807	860	TEXT	irregular
1640	0	985	807	862	TEXT	
1641	0	986	807	862	TEXT	colorless
1642	0	987	807	862	TEXT	
1643	0	988	807	862	TEXT	
1644	0	989	807	862	TEXT	
1645	0	985	807	865	TEXT	
1646	0	986	807	865	TEXT	colorless
1647	0	987	807	865	TEXT	
1648	0	988	807	865	TEXT	
1649	0	989	807	865	TEXT	
1650	0	985	870	867	TEXT	very large
1651	0	986	870	867	TEXT	
1652	0	987	870	867	TEXT	
1653	0	988	870	867	TEXT	
1654	0	989	870	867	TEXT	irregular
1655	0	985	870	873	TEXT	very large
1656	0	986	870	873	TEXT	
1657	0	987	870	873	TEXT	
1658	0	988	870	873	TEXT	
1659	0	989	870	873	TEXT	irregular
1660	0	985	870	875	TEXT	
1661	0	986	870	875	TEXT	colorless
1662	0	987	870	875	TEXT	
1663	0	988	870	875	TEXT	
1664	0	989	870	875	TEXT	circular
1665	0	985	870	878	TEXT	
1666	0	986	870	878	TEXT	colorless
1667	0	987	870	878	TEXT	
1668	0	988	870	878	TEXT	
1669	0	989	870	878	TEXT	circular
1670	0	985	870	880	TEXT	
1671	0	986	870	880	TEXT	White
1672	0	987	870	880	TEXT	
1673	0	988	870	880	TEXT	
1674	0	989	870	880	TEXT	
1675	0	985	870	882	TEXT	
1676	0	986	870	882	TEXT	white
1677	0	987	870	882	TEXT	
1678	0	988	870	882	TEXT	
1679	0	989	870	882	TEXT	
1680	0	985	870	885	TEXT	large to very large
1681	0	986	870	885	TEXT	white
1682	0	987	870	885	TEXT	
1683	0	988	870	885	TEXT	
1684	0	989	870	885	TEXT	filamentous
1685	0	985	870	888	TEXT	large to very large
1686	0	986	870	888	TEXT	white
1687	0	987	870	888	TEXT	
1688	0	988	870	888	TEXT	
1689	0	989	870	888	TEXT	filamentous
1690	0	985	870	891	TEXT	large to very large
1691	0	986	870	891	TEXT	clear to white
1692	0	987	870	891	TEXT	
1693	0	988	870	891	TEXT	umbonate
1694	0	989	870	891	TEXT	
1695	0	985	870	894	TEXT	large to very large
1696	0	986	870	894	TEXT	clear to white
1697	0	987	870	894	TEXT	
1698	0	988	870	894	TEXT	umbonate
1699	0	989	870	894	TEXT	
1700	0	985	870	897	TEXT	small
1701	0	986	870	897	TEXT	Bright yellow
1702	0	987	870	897	TEXT	
1703	0	988	870	897	TEXT	
1704	0	989	870	897	TEXT	circular
1705	0	985	870	899	TEXT	small
1706	0	986	870	899	TEXT	Bright yellow
1707	0	987	870	899	TEXT	
1708	0	988	870	899	TEXT	
1709	0	989	870	899	TEXT	circular
1710	0	985	870	901	TEXT	
1711	0	986	870	901	TEXT	bright pink
1712	0	987	870	901	TEXT	
1713	0	988	870	901	TEXT	
1714	0	989	870	901	TEXT	circular
1715	0	985	870	903	TEXT	
1716	0	986	870	903	TEXT	bright pink
1717	0	987	870	903	TEXT	
1718	0	988	870	903	TEXT	
1719	0	989	870	903	TEXT	circular
1720	0	985	908	905	TEXT	smaller than M
1721	0	986	908	905	TEXT	colorless
1722	0	987	908	905	TEXT	
1723	0	988	908	905	TEXT	flat
1724	0	989	908	905	TEXT	circular
1725	0	985	908	911	TEXT	smaller than M
1726	0	986	908	911	TEXT	colorless
1727	0	987	908	911	TEXT	
1728	0	988	908	911	TEXT	flat
1729	0	989	908	911	TEXT	circular
1730	0	985	908	913	TEXT	
1731	0	986	908	913	TEXT	colorless
1732	0	987	908	913	TEXT	
1733	0	988	908	913	TEXT	
1734	0	989	908	913	TEXT	
1735	0	985	908	915	TEXT	
1736	0	986	908	915	TEXT	colorless
1737	0	987	908	915	TEXT	
1738	0	988	908	915	TEXT	
1739	0	989	908	915	TEXT	
1740	0	985	908	917	TEXT	
1741	0	986	908	917	TEXT	white, dark red/brown center
1742	0	987	908	917	TEXT	
1743	0	988	908	917	TEXT	
1744	0	989	908	917	TEXT	circular
1745	0	985	908	919	TEXT	
1746	0	986	908	919	TEXT	white, dark red/brown center
1747	0	987	908	919	TEXT	
1748	0	988	908	919	TEXT	
1749	0	989	908	919	TEXT	circular
1750	0	985	924	925	TEXT	
1751	0	986	924	925	TEXT	white, slightly tranluscent
1752	0	987	924	925	TEXT	
1753	0	988	924	925	TEXT	
1754	0	989	924	925	TEXT	
1755	0	985	924	925	TEXT	
1756	0	986	924	925	TEXT	white, slightly tranluscent
1757	0	987	924	925	TEXT	
1758	0	988	924	925	TEXT	
1759	0	989	924	925	TEXT	
1760	0	985	930	927	TEXT	small
1761	0	986	930	927	TEXT	buff
1762	0	987	930	927	TEXT	
1763	0	988	930	927	TEXT	
1764	0	989	930	927	TEXT	
1765	0	985	930	931	TEXT	small
1766	0	986	930	931	TEXT	pale orangish-buff
1767	0	987	930	931	TEXT	
1768	0	988	930	931	TEXT	
1769	0	989	930	931	TEXT	
1770	0	985	936	933	TEXT	small
1771	0	986	936	933	TEXT	yellow
1772	0	987	936	933	TEXT	
1773	0	988	936	933	TEXT	
1774	0	989	936	933	TEXT	
1775	0	985	930	937	TEXT	med
1776	0	986	930	937	TEXT	nearly opaque; buff
1777	0	987	930	937	TEXT	
1778	0	988	930	937	TEXT	
1779	0	989	930	937	TEXT	
1780	0	985	930	939	TEXT	small
1781	0	986	930	939	TEXT	yellow
1782	0	987	930	939	TEXT	
1783	0	988	930	939	TEXT	
1784	0	989	930	939	TEXT	
1785	0	985	936	941	TEXT	med
1786	0	986	936	941	TEXT	translucent; dark buff
1787	0	987	936	941	TEXT	
1788	0	988	936	941	TEXT	
1789	0	989	936	941	TEXT	
1790	0	985	936	944	TEXT	med
1791	0	986	936	944	TEXT	nearly opaque; buff
1792	0	987	936	944	TEXT	
1793	0	988	936	944	TEXT	
1794	0	989	936	944	TEXT	
1795	0	985	930	946	TEXT	small
1796	0	986	930	946	TEXT	translucent; pale yellow
1797	0	987	930	946	TEXT	
1798	0	988	930	946	TEXT	
1799	0	989	930	946	TEXT	
1800	0	985	930	948	TEXT	
1801	0	986	930	948	TEXT	Opaque; buff
1802	0	987	930	948	TEXT	
1803	0	988	930	948	TEXT	
1804	0	989	930	948	TEXT	
1805	0	985	930	951	TEXT	
1806	0	986	930	951	TEXT	opaque; buff
1807	0	987	930	951	TEXT	
1808	0	988	930	951	TEXT	
1809	0	989	930	951	TEXT	
1810	0	985	924	954	TEXT	
1811	0	986	924	954	TEXT	translucent; buff
1812	0	987	924	954	TEXT	
1813	0	988	924	954	TEXT	
1814	0	989	924	954	TEXT	
1815	0	985	924	957	TEXT	
1816	0	986	924	957	TEXT	translucent; buff
1817	0	987	924	957	TEXT	
1818	0	988	924	957	TEXT	
1819	0	989	924	957	TEXT	
1820	0	985	924	959	TEXT	
1821	0	986	924	959	TEXT	translucent; orangish buff
1822	0	987	924	959	TEXT	
1823	0	988	924	959	TEXT	
1824	0	989	924	959	TEXT	
1825	0	985	924	961	TEXT	small
1826	0	986	924	961	TEXT	transparent; yellowish
1827	0	987	924	961	TEXT	
1828	0	988	924	961	TEXT	
1829	0	989	924	961	TEXT	
1830	0	985	930	963	TEXT	
1831	0	986	930	963	TEXT	opaque; dark buff
1832	0	987	930	963	TEXT	
1833	0	988	930	963	TEXT	raised
1834	0	989	930	963	TEXT	
1835	0	985	924	965	TEXT	
1836	0	986	924	965	TEXT	translucent; buff
1837	0	987	924	965	TEXT	
1838	0	988	924	965	TEXT	
1839	0	989	924	965	TEXT	
1840	0	985	924	967	TEXT	
1841	0	986	924	967	TEXT	opaque; orange-buff
1842	0	987	924	967	TEXT	
1843	0	988	924	967	TEXT	
1844	0	989	924	967	TEXT	
1845	0	985	924	969	TEXT	small
1846	0	986	924	969	TEXT	transparent; yellow
1847	0	987	924	969	TEXT	rough
1848	0	988	924	969	TEXT	
1849	0	989	924	969	TEXT	
1850	0	985	924	971	TEXT	
1851	0	986	924	971	TEXT	transparent; buff
1852	0	987	924	971	TEXT	
1853	0	988	924	971	TEXT	
1854	0	989	924	971	TEXT	
1855	0	985	924	973	TEXT	
1856	0	986	924	973	TEXT	transparent; buff
1857	0	987	924	973	TEXT	
1858	0	988	924	973	TEXT	
1859	0	989	924	973	TEXT	
1860	0	985	930	975	TEXT	very small
1861	0	986	930	975	TEXT	red
1862	0	987	930	975	TEXT	
1863	0	988	930	975	TEXT	
1864	0	989	930	975	TEXT	
1865	0	985	930	978	TEXT	small
1866	0	986	930	978	TEXT	pale pink
1867	0	987	930	978	TEXT	
1868	0	988	930	978	TEXT	
1869	0	989	930	978	TEXT	
1870	0	985	924	981	TEXT	
1871	0	986	924	981	TEXT	transparent; buff
1872	0	987	924	981	TEXT	
1873	0	988	924	981	TEXT	
1874	0	989	924	981	TEXT	
1875	0	985	924	983	TEXT	
1876	0	986	924	983	TEXT	transparent; buff
1877	0	987	924	983	TEXT	textured
1878	0	988	924	983	TEXT	
1879	0	989	924	983	TEXT	
\.


--
-- Data for Name: phylum; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY phylum (id, version, host, name) FROM stdin;
21	0	f	Proteobacteria (gamma)
18	1	t	Chordata
47	0	f	Firmicutes
54	0	f	Tenericutes (Mollicutes)
71	0	f	Bacteroidetes
87	0	f	Proteobacteria (beta)
96	0	f	Fusobacteria
111	0	f	Actinobacteria
211	0	f	Proteobacteria (alpha)
249	0	f	Proteobacteria
\.


--
-- Data for Name: population; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY population (id, version, capture_date, external_id, latitude, longitude, name, notes, wildtype) FROM stdin;
909	2	\N	\N	\N	\N	Millport Slough - Ocean	 [WOR] 	t
772	3	\N	\N	\N	\N	Boot Lake	 [Boot Lake]  [B pool] 	f
570	8	\N	\N	\N	\N	Rabbit Slough	 [Rabbit Slough or Boot Lake]  [Rabbit Slough]  [R7]  [R11]  [R pool 11-15] 	f
871	5	\N	\N	\N	\N	Rabbit Slough	 [WER]  [WER5]  [WER10]  [WER 8] 	t
\.


--
-- Data for Name: researcher; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY researcher (id, version, first_name, lab_id, last_name, password_hash, username) FROM stdin;
4	0	Travis	\N	Carney	ef09602427d453890bd1d94ddfb177ba6ae23913f2728b1377a7dcf8c25c92bb	tcarney@uoregon.edu
10	0	Mark	\N	Currey	ef09602427d453890bd1d94ddfb177ba6ae23913f2728b1377a7dcf8c25c92bb	mcurrey@uoregon.edu
14	0	Emily	\N	Schwarz	ef09602427d453890bd1d94ddfb177ba6ae23913f2728b1377a7dcf8c25c92bb	eshwarz@cs.uoregon.edu
1882	0	Andrea	15	Loes	e888de57712505adb2821e1c72bc334a421a7b18eeb9a4a23b1ef7e02ee94f42	aloes@uoregon.edu
5	1	Robert	15	Steury	ef09602427d453890bd1d94ddfb177ba6ae23913f2728b1377a7dcf8c25c92bb	steury@uoregon.edu
9	1	Zac	15	Stephens	ef09602427d453890bd1d94ddfb177ba6ae23913f2728b1377a7dcf8c25c92bb	wzacs1@gmail.com
3	3	Adam	15	Burns	93a2f72854b3da0c194df16600ae2975a93cee8cc8501a85489b09ba104c985e	aburns2@uoregon.edu
8	4	Chris	15	Wreden	d3314e003ac3e6e83ab9d6337c46b0f69e78bfc5045a01d5b66efabbba12826b	cwreden@uoregon.edu
540	3	Judith	539	Eisen	f2c8d25d138778631cec18c8b53e76a123bcaeece0fadb8aced12ed821c65904	eisen@uoneuro.uoregon.edu
536	2	Nick	\N	Stiffler	fce425c7d9c83c7391dc77c1483df9fd78a77092bb66e01458da26d31cb25f38	nstiffle@uoregon.edu
544	2	John	\N	Conery	ef09602427d453890bd1d94ddfb177ba6ae23913f2728b1377a7dcf8c25c92bb	conery@uoregon.edu
545	2	Kathy	15	Milligan-Myhre	b124e30084366ed9c38295cb696bba5ecf100192efc30af46367826642b3cb50	kmilliga@uoregon.edu
6	1	Nathan	\N	Dunn	dc7bab77cb868f6da7ec89ec81acb4ed2b609b8f3b0d5cf12146a51363139a50	ndunn@cas.uoregon.edu
7	3	Test	\N	Me	22ff0aa7343073d017343833f4dd0d70438b58f348bc97490f9a0bc04efcd4ed	ndunn@me.com
538	2	Travis	15	Wiles	35a5ea9db6c0b4a0e946902c33e1759a9156c50fd3678078d5c6628a6ec62722	twiles@uoregon.edu
495	2	Emily	15	Sweeney	b124e30084366ed9c38295cb696bba5ecf100192efc30af46367826642b3cb50	egoers@uoregon.edu
1881	2	Bill	1880	Cresko	ef09602427d453890bd1d94ddfb177ba6ae23913f2728b1377a7dcf8c25c92bb	wcresko@uoregon.edu
\.


--
-- Data for Name: researcher_permissions; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY researcher_permissions (researcher_id, permissions_string) FROM stdin;
\.


--
-- Data for Name: researcher_roles; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY researcher_roles (researcher_id, role_id) FROM stdin;
4	1
5	1
10	1
14	1
9	1
536	1
536	2
3	1
8	1
540	2
544	1
545	1
6	1
7	1
538	1
495	1
1881	1
1882	2
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY role (id, version, name) FROM stdin;
1	11	Administrator
2	13	User
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY role_permissions (role_id, permissions_string) FROM stdin;
1	*:*
2	experiment:edit
2	*:show
2	researcher:update
2	experiment:update
2	researcher:edit
2	strain:addFilter
2	*:list
2	strain:showFilter
\.


--
-- Data for Name: species; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY species (id, version, common_name, genus_id, name, host, prefix) FROM stdin;
20	2	Zebrafish	19	rerio	\N	Z
553	2	Stickleback	554	aculeatus	\N	SB
\.


--
-- Data for Name: species_host_genotype; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY species_host_genotype (species_genotypes_id, host_genotype_id) FROM stdin;
\.


--
-- Data for Name: stock; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY stock (id, version, box_index, box_number, general_location_id, strain_id) FROM stdin;
35	1	1	1	27	29
38	1	2	1	27	36
42	1	2147483647	2147483647	27	40
46	1	2147483647	2147483647	27	44
53	1	5	1	27	49
60	1	6	1	27	56
65	1	7	1	27	61
70	1	8	1	27	67
74	1	9	1	27	73
78	1	10	1	27	75
82	1	11	1	27	79
86	1	12	1	27	83
90	1	13	1	27	89
95	1	14	1	27	92
100	1	15	1	27	98
104	1	16	1	27	102
107	1	17	1	27	105
110	1	18	1	27	109
115	1	19	1	27	113
119	1	20	1	27	117
123	1	21	1	27	121
126	1	22	1	27	125
131	1	23	1	27	128
134	1	24	1	27	132
136	1	25	1	27	135
138	1	26	1	27	137
140	1	27	1	27	139
142	1	28	1	27	141
144	1	29	1	27	143
146	1	30	1	27	145
148	1	31	1	27	147
150	1	32	1	27	149
152	1	33	1	27	151
156	1	34	1	27	153
159	1	35	1	27	158
162	1	36	1	27	160
165	1	37	1	27	163
167	1	38	1	27	166
169	1	39	1	27	168
171	1	40	1	27	170
173	1	41	1	27	172
175	1	42	1	27	174
177	1	43	1	27	176
179	1	44	1	27	178
181	1	45	1	27	180
183	1	46	1	27	182
185	1	47	1	27	184
187	1	48	1	27	186
189	1	49	1	27	188
193	1	50	1	27	191
196	1	51	1	27	195
198	1	52	1	27	197
200	1	53	1	27	199
205	1	54	1	27	202
207	1	55	1	27	206
210	1	56	1	27	209
215	1	58	1	27	213
220	1	59	1	27	217
223	1	60	1	27	221
228	1	61	1	27	224
232	1	62	1	27	229
235	1	57	1	27	234
238	1	63	1	27	236
241	1	65	1	27	239
245	1	64	1	27	242
26	2	23	1	27	\N
567	0	2	55	27	566
573	0	2	56	27	572
575	0	2	57	27	574
577	0	2	58	27	576
579	0	2147483647	2147483647	27	578
581	0	2	60	27	580
583	0	2	61	27	582
585	0	2	62	27	584
587	0	2	63	27	586
589	0	2	64	27	588
591	0	2	65	27	590
593	0	2	66	27	592
595	0	2147483647	2147483647	27	594
597	0	2	68	27	596
599	0	2147483647	2147483647	27	598
601	0	2	70	27	600
603	0	2	71	27	602
605	0	2	72	27	604
607	0	2	73	27	606
609	0	2147483647	2147483647	27	608
611	0	2	75	27	610
613	0	2	76	27	612
615	0	2	28	27	614
618	0	2	29	27	617
620	0	2	30	27	619
622	0	2	31	27	621
624	0	2	32	27	623
626	0	2	33	27	625
628	0	2	34	27	627
630	0	2	35	27	629
632	0	2	36	27	631
634	0	2	37	27	633
636	0	2	38	27	635
638	0	2	39	27	637
640	0	2	40	27	639
642	0	2	41	27	641
644	0	2147483647	2147483647	27	643
646	0	2	43	27	645
648	0	2	44	27	647
650	0	2	45	27	649
652	0	2147483647	2147483647	27	651
654	0	2	47	27	653
656	0	2	48	27	655
658	0	2147483647	2147483647	27	657
660	0	2	50	27	659
662	0	2	51	27	661
664	0	2	52	27	663
666	0	2	53	27	665
668	0	2	54	27	667
670	0	3	34	27	669
674	0	3	35	27	673
676	0	3	36	27	675
678	0	3	37	27	677
680	0	3	38	27	679
682	0	3	39	27	681
684	0	3	40	27	683
686	0	3	41	27	685
688	0	3	42	27	687
690	0	3	43	27	689
692	0	3	44	27	691
694	0	3	45	27	693
696	0	3	46	27	695
698	0	3	47	27	697
700	0	3	48	27	699
703	0	2147483647	2147483647	27	702
706	0	3	50	27	705
708	0	2147483647	2147483647	27	707
710	0	2147483647	2147483647	27	709
712	0	3	53	27	711
714	0	3	54	27	713
716	0	3	55	27	715
718	0	2147483647	2147483647	27	717
720	0	3	57	27	719
722	0	3	58	27	721
724	0	2147483647	2147483647	27	723
726	0	3	59	27	725
728	0	1	13	27	727
733	0	1	14	27	732
736	0	2147483647	2147483647	27	735
739	0	2147483647	2147483647	27	738
741	0	1	15	27	740
744	0	2147483647	2147483647	27	743
747	0	2147483647	2147483647	27	746
749	0	1	16	27	748
752	0	2147483647	2147483647	27	751
754	0	2147483647	2147483647	27	753
756	0	1	17	27	755
758	0	1	18	27	757
761	0	1	19	27	760
764	0	2147483647	2147483647	27	763
766	0	2147483647	2147483647	27	765
769	0	1	20	27	768
771	0	1	1	27	770
775	0	1	2	27	774
777	0	1	3	27	776
779	0	1	4	27	778
781	0	1	5	27	780
784	0	2147483647	2147483647	27	783
787	0	2147483647	2147483647	27	786
789	0	1	6	27	788
792	0	1	7	27	791
794	0	1	8	27	793
796	0	1	9	27	795
798	0	1	10	27	797
800	0	1	11	27	799
803	0	1	12	27	802
805	0	1	28	27	804
809	0	1	29	27	808
811	0	1	30	27	810
814	0	1	31	27	813
817	0	1	32	27	816
820	0	1	33	27	819
822	0	1	34	27	821
824	0	1	35	27	823
827	0	1	36	27	826
830	0	2147483647	2147483647	27	829
832	0	2147483647	2147483647	27	831
834	0	1	37	27	833
837	0	2147483647	2147483647	27	836
839	0	2147483647	2147483647	27	838
841	0	1	38	27	840
843	0	1	39	27	842
845	0	1	40	27	844
847	0	1	41	27	846
849	0	1	42	27	848
851	0	1	43	27	850
853	0	1	44	27	852
855	0	1	45	27	854
858	0	1	46	27	857
861	0	1	47	27	860
863	0	1	48	27	862
866	0	1	49	27	865
868	0	1	50	27	867
874	0	1	51	27	873
876	0	1	52	27	875
879	0	1	53	27	878
881	0	1	54	27	880
883	0	1	55	27	882
886	0	1	56	27	885
889	0	1	57	27	888
892	0	1	58	27	891
895	0	1	59	27	894
898	0	1	60	27	897
900	0	1	61	27	899
902	0	1	62	27	901
904	0	1	63	27	903
906	0	1	64	27	905
912	0	1	65	27	911
914	0	1	66	27	913
916	0	1	67	27	915
918	0	1	68	27	917
920	0	1	69	27	919
922	0	2147483647	2147483647	27	921
926	0	2147483647	2147483647	27	925
928	0	2	1	27	927
932	0	2	2	27	931
934	0	2	3	27	933
938	0	2	4	27	937
940	0	2	5	27	939
942	0	2	6	27	941
945	0	2	7	27	944
947	0	2	8	27	946
949	0	2	9	27	948
952	0	2	10	27	951
955	0	2	11	27	954
958	0	2	12	27	957
960	0	2	13	27	959
962	0	2	14	27	961
964	0	2	15	27	963
966	0	2	16	27	965
968	0	2	17	27	967
970	0	2	18	27	969
972	0	2	19	27	971
974	0	2	20	27	973
976	0	2	21	27	975
979	0	2	22	27	978
982	0	2	23	27	981
984	0	2	24	27	983
\.


--
-- Data for Name: strain; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY strain (id, version, date_entered, former_clone_alias, genus_id, host_origin_id, isolate_condition_id, name, notes, parent_strain_id, strain_genotype_id, sequence16s) FROM stdin;
242	3	\N	ZF1NF03, Z10 (Zac)	101	225	243	ZWU0021	\N	\N	\N	\N
239	6	\N	ZF1NH01, Z09 (Zac)	97	225	99	ZWU0022	Able to grow on BHI plate, but not in BHI liquid culture (both anaerobic)-CCW 8-22-13	\N	\N	\N
36	2	\N	TC022	28	32	33	ZOR0002	Passaged once from original TC collection isolated by Travis Carney	\N	\N	\N
40	1	\N	TC023	39	32	41	ZOR0003		\N	\N	\N
44	1	\N	TC020	43	32	45	ZOR0004		\N	\N	\N
73	3	2013-09-08 00:00:00	ZI6-37	72	58	64	ZOR0009	Can't grow from stock (anaerobic BHI agar, 30C)	\N	\N	\N
141	2	2012-09-12 00:00:00	M17-04	28	84	93	ZOR0028		\N	\N	\N
61	2	2013-09-08 00:00:00	ZI6-36	55	63	64	ZOR0007		\N	\N	\N
178	2	2012-09-12 00:00:00	NA-02	43	84	93	ZOR0044		\N	\N	\N
67	3	\N	ZI-06	66	68	45	ZOR0008		\N	\N	\N
143	2	2012-09-12 00:00:00	M17-07	28	84	93	ZOR0029		\N	\N	\N
75	2	2013-09-08 00:00:00	ZI6-17	22	77	52	ZOR0010		\N	\N	\N
145	2	2012-09-12 00:00:00	NA-06	28	84	93	ZOR0030		\N	\N	\N
79	3	\N	ZS4-1	22	80	25	ZOR0011		\N	\N	\N
147	1	2012-09-12 00:00:00	ZS4-7	28	80	\N	ZOR0031		\N	\N	\N
83	3	\N	M17-02	43	84	25	ZOR0012		\N	\N	\N
89	2	2013-09-08 00:00:00	ZI6-06	88	51	52	ZOR0013		\N	\N	\N
149	1	2012-09-12 00:00:00	MAn-02	28	84	\N	ZOR0032		\N	\N	\N
180	1	2012-09-12 00:00:00	ZS4-5	39	80	\N	ZOR0045		\N	\N	\N
92	3	\N	M17-05	91	84	93	ZOR0014		\N	\N	\N
98	2	\N	ZA2-e	97	68	99	ZOR0015		\N	\N	\N
151	2	2012-09-12 00:00:00	ZA2-c	97	\N	99	ZOR0033		\N	\N	\N
102	2	\N	MAn-04	101	84	103	ZOR0016		\N	\N	\N
105	2	\N	ZS4-2	88	80	106	ZOR0017		\N	\N	\N
153	2	2013-09-08 00:00:00	ZI6-29	97	77	155	ZOR0034		\N	\N	\N
109	2	\N	ZS4-6	108	80	25	ZOR0018		\N	\N	\N
113	3	\N	ZS4-9	112	80	106	ZOR0019		\N	\N	\N
117	3	\N	ZS4-12	116	80	106	ZOR0020	In culture (shaking, BHI), grows in clumps rather than homogenous (4/25/12-ZS)	\N	\N	\N
182	2	2012-09-12 00:00:00	M17-01	39	84	93	ZOR0046		\N	\N	\N
121	2	\N	ROB-A1	120	122	106	ZOR0021	No permanent stock	\N	\N	\N
125	2	\N	ROB-10	124	80	106	ZOR0022	No permanent stock	\N	\N	\N
217	2	\N	SWZG02.006	216	\N	\N	ZNC0032		\N	\N	\N
160	2	2013-09-08 00:00:00	ZI6-12	157	161	52	ZOR0036		\N	\N	\N
135	2	2012-09-12 00:00:00	ZA2-a	28	\N	99	ZOR0025		\N	\N	\N
197	2	2012-09-12 00:00:00	ZS4-10	112	80	106	ZOR0052		\N	\N	\N
137	2	2012-09-12 00:00:00	ZA2-d	28	\N	99	ZOR0026		\N	\N	\N
163	2	2013-09-08 00:00:00	ZI6-35	157	164	64	ZOR0037		\N	\N	\N
184	2	2012-09-12 00:00:00	M17-06	39	84	93	ZOR0047		\N	\N	\N
166	2	2013-09-08 00:00:00	ZI6-40	28	51	64	ZOR0038		\N	\N	\N
221	2	\N	SWZG02.015	216	\N	\N	ZNC0037		\N	\N	\N
168	2	2013-09-08 00:00:00	ZI6-31	28	77	155	ZOR0039		\N	\N	\N
170	2	2013-09-08 00:00:00	ZI6-07	43	58	52	ZOR0040		\N	\N	\N
172	1	2012-09-12 00:00:00	MAn-03	43	84	\N	ZOR0041		\N	\N	\N
174	1	2012-09-12 00:00:00	ZS4-3	43	80	\N	ZOR0042		\N	\N	\N
176	1	2012-09-12 00:00:00	ZS4-4	43	80	\N	ZOR0043		\N	\N	\N
199	2	2012-09-12 00:00:00	NA-04	91	84	93	ZOR0053		\N	\N	\N
186	2	2012-09-12 00:00:00	NA-01	39	84	93	ZOR0048		\N	\N	\N
188	2	2012-09-12 00:00:00	NA-05	39	84	93	ZOR0049		\N	\N	\N
191	2	2013-09-08 00:00:00	ZI6-25	190	192	155	ZOR0050	Associated with human skin	\N	\N	\N
206	2	\N	SWZG01.007	120	\N	\N	ZNC0007		\N	\N	\N
195	2	2013-09-08 00:00:00	ZI6-14A	194	77	52	ZOR0051	Associated with human skin, but also in environmental water	\N	\N	\N
209	2	\N	SWZG01.008	208	\N	\N	ZNC0008		\N	\N	\N
213	2	\N	SWZG02.002	212	\N	\N	ZNC0028		\N	\N	\N
132	2	\N	KG4dpf-15, 4dpf-15	39	133	\N	ZOR0024		\N	\N	\N
236	3	\N	ZF1EF01, Z03 (Zac)	157	225	25	ZWU0020	\N	\N	\N	\N
29	3	\N	TC021	28	32	33	ZOR0001	Passaged once from original TC collection isolated by Travis Carney	\N	\N	\N
234	2	\N	T1N1E05	233	\N	\N	ZWU0011		\N	\N	\N
128	4	\N	KG3dpf.1	127	130	\N	ZOR0023		\N	\N	\N
247	1	\N	T1E1A03	246	\N	\N	ZWU0001		\N	\N	\N
229	4	\N	ZF1EB02, Z06 (Zac)	48	225	230	ZWU0009	\N	\N	\N	\N
251	1	\N	T1E1B07	28	\N	\N	ZWU0002		\N	\N	\N
253	1	\N	M2E1A04	101	\N	\N	MWU0001		\N	\N	\N
255	1	\N	T1E1D10	101	\N	\N	ZWU0003		\N	\N	\N
258	1	\N	T1E1H07	28	\N	\N	ZWU0004		\N	\N	\N
260	1	\N	This clone recovered accidentally while trying to recover Chitinibacter clone ZF1ED01 from glycerol plate	22	\N	\N	ZWU0005	glycerol stock made by Chad Trent (JFR: origin unknown - do not use)	\N	\N	\N
264	1	\N	M2E1F06	263	\N	\N	MWU0002		\N	\N	\N
267	1	\N	TSFNXAE.F12	266	\N	\N	ZWU0007		\N	\N	\N
269	1	\N	M2E1G02	266	\N	\N	MWU0003		\N	\N	\N
271	1	\N	T1E1A06	28	\N	\N	ZWU0008		\N	\N	\N
274	1	\N	M2E1D03	263	\N	\N	MWU0004		\N	\N	\N
276	1	\N	T1E1A07	28	\N	\N	ZWU0010		\N	\N	\N
158	3	2013-09-08 00:00:00	ZI6-02	157	51	52	ZOR0035	Grew in Brucella Broth+10%FBS liquid culture 30C	\N	\N	\N
139	3	2012-09-12 00:00:00	M17-03	28	84	93	ZOR0027	where does this box end up?	\N	\N	\N
283	1	\N	T1E1C07	282	\N	\N	ZWU0013		\N	\N	\N
285	1	\N	M2E1D05	263	\N	\N	MWU0005		\N	\N	\N
288	1	\N	T1N1G10	287	\N	\N	ZWU0014		\N	\N	\N
290	1	\N	T1N1D03	22	\N	\N	ZWU0015		\N	\N	\N
292	1	\N	ZF1EF05	28	\N	\N	ZWU0016		\N	\N	\N
294	1	\N	ZFMB1AE.E7, ZF1EE07	39	\N	\N	ZWU0017	same as ZWR0006?	\N	\N	\N
296	1	\N	T1N1F08	282	\N	\N	ZWU0018		\N	\N	\N
299	1	\N	This clone recovered accidentally while trying to recover Chitinibacter clone ZF1ED01 from glycerol plate	22	\N	\N	ZWU0019	glycerol stock made by Jessica Russell (JFR: origin unknown - do not use)	\N	\N	\N
301	1	\N	SWZG01.001	28	\N	\N	ZNC0001		\N	\N	\N
302	1	\N	SWZG01.002	\N	\N	\N	ZNC0002		\N	\N	\N
305	1	\N	SWZG01.003	28	\N	\N	ZNC0003		\N	\N	\N
307	1	\N	SWZG01.004	39	\N	\N	ZNC0004		\N	\N	\N
309	1	\N	SWZG01.005	39	\N	\N	ZNC0005		\N	\N	\N
314	1	\N	SWZG01.009	39	\N	\N	ZNC0009		\N	\N	\N
316	1	\N	SWZG01.010	28	\N	\N	ZNC0010		\N	\N	\N
318	1	\N	SWZG01.011	28	\N	\N	ZNC0011		\N	\N	\N
320	1	\N	SWZG01.012	208	\N	\N	ZNC0012		\N	\N	\N
322	1	\N	SWZG01.013	120	\N	\N	ZNC0013		\N	\N	\N
324	1	\N	SWZG01.014	28	\N	\N	ZNC0014		\N	\N	\N
326	1	\N	SWZG01.015	39	\N	\N	ZNC0015		\N	\N	\N
329	1	\N	SWZG01.016	328	\N	\N	ZNC0016		\N	\N	\N
331	1	\N	SWZG01.017	208	\N	\N	ZNC0017		\N	\N	\N
333	1	\N	SWZG01.018	39	\N	\N	ZNC0018		\N	\N	\N
335	1	\N	SWZG01.019	201	\N	\N	ZNC0019		\N	\N	\N
337	1	\N	SWZG01.020	208	\N	\N	ZNC0020		\N	\N	\N
339	1	\N	SWZG01.021	208	\N	\N	ZNC0021		\N	\N	\N
341	1	\N	SWZG01.022	39	\N	\N	ZNC0022		\N	\N	\N
343	1	\N	SWZG01.023	39	\N	\N	ZNC0023		\N	\N	\N
345	1	\N	SWZG01.024	39	\N	\N	ZNC0024		\N	\N	\N
347	1	\N	SWZG01.025	39	\N	\N	ZNC0025		\N	\N	\N
350	1	\N	SWZG01.026	349	\N	\N	ZNC0026		\N	\N	\N
352	1	\N	SWZG02.001	112	\N	\N	ZNC0027		\N	\N	\N
355	1	\N	SWZG02.003	112	\N	\N	ZNC0029		\N	\N	\N
356	1	\N	SWZG02.004	\N	\N	\N	ZNC0030		\N	\N	\N
360	1	\N	SWZG02.005	359	\N	\N	ZNC0031		\N	\N	\N
365	1	\N	SWZG02.007	364	\N	\N	ZNC0033		\N	\N	\N
368	1	\N	SWZG02.008	112	\N	\N	ZNC0034		\N	\N	\N
370	1	\N	SWZG02.009	216	\N	\N	ZNC0035		\N	\N	\N
372	1	\N	SWZG02.012	112	\N	\N	ZNC0036		\N	\N	\N
375	1	\N	SWZG02.016	112	\N	\N	ZNC0038		\N	\N	\N
377	1	\N	SWZG02.017	216	\N	\N	ZNC0039		\N	\N	\N
379	1	\N	SWZG02.019	112	\N	\N	ZNC0040		\N	\N	\N
381	1	\N	SWZG02.021	359	\N	\N	ZNC0041		\N	\N	\N
384	1	\N	SWZG02.023	359	\N	\N	ZNC0042		\N	\N	\N
386	1	\N	SWZG02.024	359	\N	\N	ZNC0043		\N	\N	\N
388	1	\N	SWZG02.026	359	\N	\N	ZNC0044		\N	\N	\N
23	3	\N	This clone recovered accidentally while trying to recover clone ZF1ED01 from glycerol plate	22	\N	25	ZWU0023	DO NOT USE!  Not in stock box.\r\nSent as Chitinbacter, 16S seqeunce indicates Plesiomonas (Sandi: this might actually be ZWU0005? My version of ZF1ED01 is a Plesiomonas)(JFR: origin unknown - do not use)	\N	\N	\N
279	2	\N	TSFN1AE.C5, T1E1C05	43	\N	\N	ZWU0012	Generally, DON'T USE!  Better Shewanella is ZOR0012.  This strain  (ZWU0012) is a strain passaged through mouse in John Rawl's study.  Originally isolated from zebrafish though.  	\N	\N	\N
56	5	2013-09-08 00:00:00	ZI6-20	537	58	59	ZOR0006	This strain looks to be from a novel class of Firmicutes.  Likely CK_1C4_19.  Previous assignment as Haloplasma was based off short, poor-quality sequence.  Closest related class seems to be Erysipelotrichia [49% conf. RDP]. Cant grow from stock.	\N	\N	\N
224	5	\N	ZF1EE07, Z02 (Zac)	39	225	226	ZWU0006	Unable to grow in liquid after 4C O/N	\N	\N	\N
202	5	\N	SWZG01.006	201	\N	\N	ZNC0006	Unable to grow in liquid after 4C O/N	\N	\N	\N
49	3	2013-09-08 00:00:00	ZI6-05	48	51	52	ZOR0005	Grew in Brucella Broth+10%FBS liquid culture 30C	\N	\N	\N
574	2	\N	\N	\N	571	568	SBOR0003	nullOld Strain Index: SB-1-003\nStrain Species: actinobacterium\nStrain Note: Same size as 2, bumpy surface\n	\N	\N	\N
566	2	\N	\N	\N	571	568	SBOR0001	nullOld Strain Index: SB-1-001\nStrain Species: actinobacterium\nStrain Note: Convex, Maybe Clavibacter michigenesis\n	\N	\N	\N
572	2	\N	\N	\N	571	568	SBOR0002	nullOld Strain Index: SB-1-002\nStrain Species: actinobacterium\nStrain Note: Convex, slightly bigger (2X) than SB-1-001 (1mm), Maybe Liefsonia xyli\n	\N	\N	\N
578	2	\N	\N	39	571	568	SBOR0005	nullOld Strain Index: SB-1-005\nStrain Species: fluorescens\nStrain Note: transleucent, matte\n	\N	\N	\N
576	2	\N	\N	556	571	568	SBOR0004	nullOld Strain Index: SB-1-004\nStrain Species: violaccum\nStrain Note: Glossy\n	\N	\N	\N
580	2	\N	\N	124	571	568	SBOR0006	nullOld Strain Index: SB-1-006\nStrain Species: cereus\nStrain Note: "mold" matte\n	\N	\N	\N
582	2	\N	\N	28	571	568	SBOR0007	nullOld Strain Index: SB-1-007\nStrain Species: hydrophila\nStrain Note: shiny, transleucent\n	\N	\N	\N
584	2	\N	\N	157	571	568	SBOR0008	nullOld Strain Index: SB-1-008\nStrain Species: metschrikouii\nStrain Note: Transparent\n	\N	\N	\N
586	2	\N	\N	157	571	568	SBOR0009	nullOld Strain Index: SB-1-009\nStrain Note: glrows with others, transleucent, shiny\n	\N	\N	\N
588	2	\N	\N	124	571	568	SBOR0010	nullOld Strain Index: SB-1-010\nStrain Species: cereus\nStrain Note: globular, opaque\n	\N	\N	\N
590	2	\N	\N	\N	571	568	SBOR0011	nullOld Strain Index: SB-1-011\nStrain Species: Lutiella nitroferrum or Chromobacerium violaccum\nStrain Note: opaque\n	\N	\N	\N
691	2	\N	\N	\N	672	671	SBOR0060	nullOld Strain Index: SB-2-010 B\n	\N	\N	\N
592	2	\N	\N	\N	571	568	SBOR0012	nullOld Strain Index: SB-1-012\nStrain Species: actinobacterium\nStrain Note: Transparent\n	\N	\N	\N
594	2	\N	\N	\N	571	568	SBOR0013	nullOld Strain Index: SB-1-013\nStrain Note: "Donut dude", craterform\n	\N	\N	\N
643	2	\N	\N	\N	571	616	SBOR0037	nullOld Strain Index: SB-1-015AN\nStrain Note: grey under scope, sime in size to 5 & 9\n	\N	\N	\N
596	2	\N	\N	157	571	568	SBOR0014	nullOld Strain Index: SB-1-014\nStrain Species: alginolyticus\nStrain Note: opaque\n	\N	\N	\N
625	2	\N	\N	\N	571	616	SBOR0028	nullOld Strain Index: SB-1-006AN\n	\N	\N	\N
598	2	\N	\N	\N	571	568	SBOR0015	nullOld Strain Index: SB-1-015\nStrain Species: denitrificans\nStrain Note: mucoid opaque\n	\N	\N	\N
600	2	\N	\N	124	571	568	SBOR0016	nullOld Strain Index: SB-1-016\nStrain Species: sp\nStrain Note: shiny, opaque, mucoid, concave\n	\N	\N	\N
602	2	\N	\N	\N	571	568	SBOR0017	nullOld Strain Index: SB-1-017\nStrain Species: sp\nStrain Note: transleucent, matte\n	\N	\N	\N
627	2	\N	\N	\N	571	616	SBOR0029	nullOld Strain Index: SB-1-007AN\n	\N	\N	\N
604	2	\N	\N	157	571	568	SBOR0018	nullOld Strain Index: SB-1-018\nStrain Species: harvey or Sp. Ex25\nStrain Note: transparent, "Over-easy egg"\n	\N	\N	\N
606	2	\N	\N	124	571	568	SBOR0019	nullOld Strain Index: SB-1-019\nStrain Species: sp. M3-13 or megaterium\nStrain Note: transparent\n	\N	\N	\N
655	2	\N	\N	263	571	616	SBOR0043	nullOld Strain Index: SB-1-021AN\nStrain Species: casselifavus\nStrain Note: edges are darker than center\n	\N	\N	\N
608	2	\N	\N	\N	571	568	SBOR0020	nullOld Strain Index: SB-1-020\nStrain Note: transparent, matte center, bumpy\n	\N	\N	\N
629	2	\N	\N	\N	571	616	SBOR0030	nullOld Strain Index: SB-1-008AN\nStrain Species: Lutiella nitroferrum/Chromobacterium violaceum\n	\N	\N	\N
610	2	\N	\N	124	571	568	SBOR0021	nullOld Strain Index: SB-1-021\nStrain Species: cereus\nStrain Note: matte center (bigger than 20)\n	\N	\N	\N
612	2	\N	\N	124	571	568	SBOR0022	nullOld Strain Index: SB-1-022\nStrain Species: cereus\nStrain Note: transparent "totally"\n	\N	\N	\N
645	2	\N	\N	\N	571	616	SBOR0038	nullOld Strain Index: SB-1-016AN\nStrain Note: center more brown than edge\n	\N	\N	\N
614	2	\N	\N	28	571	616	SBOR0023	nullOld Strain Index: SB-1-001AN\nStrain Species: hydrophila\n	\N	\N	\N
631	2	\N	\N	\N	571	616	SBOR0031	nullOld Strain Index: SB-1-009AN\nStrain Note: "button" colony\n	\N	\N	\N
617	2	\N	\N	28	571	616	SBOR0024	nullOld Strain Index: SB-1-002AN\nStrain Species: hydrophila\n	\N	\N	\N
619	2	\N	\N	157	571	616	SBOR0025	nullOld Strain Index: SB-1-003AN\nStrain Species: Sp.\n	\N	\N	\N
621	2	\N	\N	28	571	616	SBOR0026	nullOld Strain Index: SB-1-004AN\nStrain Species: hydrophila\n	\N	\N	\N
633	2	\N	\N	\N	571	616	SBOR0032	nullOld Strain Index: SB-1-010AN\nStrain Note: Center has additional spots\n	\N	\N	\N
623	2	\N	\N	\N	571	616	SBOR0027	nullOld Strain Index: SB-1-005AN\nStrain Species: Lutiella nitroferrum/Chromobacterium violaceum\n	\N	\N	\N
635	2	\N	\N	\N	571	616	SBOR0033	nullOld Strain Index: SB-1-011AN\nStrain Note: center has very clear edge, and brown (under scope) into edge of colony\n	\N	\N	\N
647	2	\N	\N	43	571	616	SBOR0039	nullOld Strain Index: SB-1-017AN\nStrain Species: sp.\nStrain Note: raised in center\n	\N	\N	\N
637	2	\N	\N	157	571	616	SBOR0034	nullOld Strain Index: SB-1-012AN\nStrain Species: sp.\nStrain Note: sim to 002 and 003, under scope color is inbetween 2 & 3\n	\N	\N	\N
639	2	\N	\N	287	571	616	SBOR0035	nullOld Strain Index: SB-1-013AN\nStrain Species: carboxivorans\nStrain Note: under scope, med brown\n	\N	\N	\N
641	2	\N	\N	157	571	616	SBOR0036	nullOld Strain Index: SB-1-014AN\nStrain Species: furnissii\nStrain Note: large, smeary, difficult to tell if one colony or many\n	\N	\N	\N
657	2	\N	\N	\N	571	616	SBOR0044	nullOld Strain Index: SB-1-022AN\n	\N	\N	\N
649	2	\N	\N	28	571	616	SBOR0040	nullOld Strain Index: SB-1-018AN\nStrain Species: hydrophila/ salmonicida\nStrain Note: egg over easy; center grey under scope\n	\N	\N	\N
651	2	\N	\N	\N	571	616	SBOR0041	nullOld Strain Index: SB-1-019AN\nStrain Note: streaks of smears with nodes\n	\N	\N	\N
665	2	\N	\N	157	571	616	SBOR0048	nullOld Strain Index: SB-1-026AN\nStrain Species: alginolyticus\nStrain Note: bumpy in center\n	\N	\N	\N
653	2	\N	\N	28	571	616	SBOR0042	nullOld Strain Index: SB-1-020AN\nStrain Species: hydrophila\nStrain Note: very dark under scope\n	\N	\N	\N
659	2	\N	\N	157	571	616	SBOR0045	nullOld Strain Index: SB-1-023AN\nStrain Species: sp.\n	\N	\N	\N
669	2	\N	\N	124	672	671	SBOR0050	nullOld Strain Index: SB-2-001\nStrain Species: subtilis\nStrain Note: circle in center\n	\N	\N	\N
661	2	\N	\N	\N	571	616	SBOR0046	nullOld Strain Index: SB-1-024AN\nStrain Species: delafieldii\nStrain Note: fried egg\n	\N	\N	\N
667	2	\N	\N	\N	571	616	SBOR0049	nullOld Strain Index: SB-1-27AN\nStrain Note: under scope: dark brown edge, light brown ring, dark brown center\n	\N	\N	\N
663	2	\N	\N	\N	571	616	SBOR0047	nullOld Strain Index: SB-1-025AN\n	\N	\N	\N
673	2	\N	\N	124	672	671	SBOR0051	nullOld Strain Index: SB-2-002\nStrain Species: cereus\n	\N	\N	\N
675	2	\N	\N	43	672	671	SBOR0052	nullOld Strain Index: SB-2-003\nStrain Species: putrefaciens\n	\N	\N	\N
677	2	\N	\N	48	672	671	SBOR0053	nullOld Strain Index: SB-2-004\nStrain Species: sibiricum\n	\N	\N	\N
679	2	\N	\N	39	672	671	SBOR0054	nullOld Strain Index: SB-2-005\nStrain Species: mendocina\n	\N	\N	\N
681	2	\N	\N	\N	672	671	SBOR0055	nullOld Strain Index: SB-2-006\n	\N	\N	\N
683	2	\N	\N	\N	672	671	SBOR0056	nullOld Strain Index: SB-2-007\n	\N	\N	\N
685	2	\N	\N	\N	672	671	SBOR0057	nullOld Strain Index: SB-2-008\nStrain Species: cryohalolentis\nStrain Note: may be same as 7, but bigger\n	\N	\N	\N
687	2	\N	\N	124	672	671	SBOR0058	nullOld Strain Index: SB-2-009\nStrain Species: subtilis\n	\N	\N	\N
689	2	\N	\N	124	672	671	SBOR0059	nullOld Strain Index: SB-2-010 A\nStrain Species: subtilis\n	\N	\N	\N
693	2	\N	\N	246	672	671	SBOR0061	nullOld Strain Index: SB-2-011\n	\N	\N	\N
695	2	\N	\N	562	672	671	SBOR0062	nullOld Strain Index: SB-2-012\nStrain Species: odorifera\n	\N	\N	\N
697	2	\N	\N	39	672	671	SBOR0063	nullOld Strain Index: SB-2-013\nStrain Species: mendocina\n	\N	\N	\N
738	2	\N	\N	\N	731	737	SBOR0080	nullOld Strain Index: sbr02 white\nStrain Note: dull, opaque\n	\N	\N	\N
699	2	\N	\N	\N	672	701	SBOR0064	nullOld Strain Index: SB-2-001 AN\nStrain Note: Lytic\n	\N	\N	\N
702	2	\N	\N	\N	672	704	SBOR0065	nullOld Strain Index: SB-2-002 AN\nStrain Note: Lytic\n	\N	\N	\N
768	2	\N	\N	\N	731	767	SBOR0092	nullOld Strain Index: SBR08\nStrain Note: translucent, dull; usually found with other colonies\n	\N	\N	\N
705	2	\N	\N	\N	672	704	SBOR0066	nullOld Strain Index: SB-2-003 AN\nStrain Note: Lytic\n	\N	\N	\N
740	2	\N	\N	\N	731	742	SBOR0081	nullOld Strain Index: SBR03\nStrain Species: -\nStrain Note: Center opaque; glossy\n	\N	\N	\N
707	2	\N	\N	\N	672	704	SBOR0067	nullOld Strain Index: SB-2-004 AN\n	\N	\N	\N
709	2	\N	\N	\N	672	704	SBOR0068	nullOld Strain Index: SB-2-005 AN\n	\N	\N	\N
711	2	\N	\N	\N	672	704	SBOR0069	nullOld Strain Index: SB-2-006 AN\n	\N	\N	\N
743	2	\N	\N	561	731	745	SBOR0082	nullOld Strain Index: sbr03 yellow\n	\N	\N	\N
713	2	\N	\N	\N	672	704	SBOR0070	nullOld Strain Index: SB-2-007 AN\n	\N	\N	\N
715	2	\N	\N	\N	672	704	SBOR0071	nullOld Strain Index: SB-2-008 AN\n	\N	\N	\N
717	2	\N	\N	\N	672	704	SBOR0072	nullOld Strain Index: SB-2-009 AN\nStrain Note: Can't count-too small. Presence or absence on 103 plates marked\n	\N	\N	\N
746	2	\N	\N	\N	731	737	SBOR0083	nullOld Strain Index: sbr03 white\n	\N	\N	\N
719	2	\N	\N	\N	672	704	SBOR0073	nullOld Strain Index: SB-2-010 AN\nStrain Note: Lytic; Very large; uneven edges may be due to smaller conolies growing into colony; may be same as 1\n	\N	\N	\N
721	2	\N	\N	\N	672	704	SBOR0074	nullOld Strain Index: SB-2-011 AN\n	\N	\N	\N
770	2	\N	\N	39	773	737	SBOR0093	nullOld Strain Index: SBB01\nStrain Note: mucoid; colony ruptured when sampled; produced mucus like string\n	\N	\N	\N
723	2	\N	\N	\N	672	704	SBOR0075	nullOld Strain Index: SB-2-012 AN\nStrain Note: shiny; large when have space to grow\n	\N	\N	\N
748	2	\N	\N	\N	731	750	SBOR0084	nullOld Strain Index: SBR04\nStrain Note: rough; opaque\n	\N	\N	\N
725	2	\N	\N	\N	672	704	SBOR0076	nullOld Strain Index: SB-2-013 AN\n	\N	\N	\N
727	2	\N	\N	39	731	729	SBOR0077	nullOld Strain Index: SBR01\nStrain Note: Slightly translucent, glossy\n	\N	\N	\N
732	2	\N	\N	\N	731	734	SBOR0078	nullOld Strain Index: SBR02\nStrain Species: -\nStrain Note: dull, opaque\n	\N	\N	\N
751	2	\N	\N	556	731	737	SBOR0085	nullOld Strain Index: sbr04 yellow\n	\N	\N	\N
735	2	\N	\N	561	731	737	SBOR0079	nullOld Strain Index: sbr02 yellow\nStrain Note: dull, opaque\n	\N	\N	\N
786	2	\N	\N	\N	773	737	SBOR0099	nullOld Strain Index: sbb05 med\n	\N	\N	\N
753	2	\N	\N	\N	731	737	SBOR0086	nullOld Strain Index: sbr04 white\n	\N	\N	\N
774	2	\N	\N	561	773	737	SBOR0094	nullOld Strain Index: SBB02\nStrain Note: dull; opaque\n	\N	\N	\N
755	2	\N	\N	39	731	745	SBOR0087	nullOld Strain Index: SBR05\nStrain Note: opaque; dusty\n	\N	\N	\N
757	2	\N	\N	22	731	759	SBOR0088	nullOld Strain Index: SBR06\nStrain Note: translucent, glossy\n	\N	\N	\N
760	2	\N	\N	556	731	762	SBOR0089	nullOld Strain Index: SBR07\nStrain Note: translucent, smooth, glossy\n	\N	\N	\N
776	2	\N	\N	124	773	745	SBOR0095	nullOld Strain Index: SBB03\nStrain Note: undulate; cloudy, glassy\n	\N	\N	\N
763	2	\N	\N	\N	731	759	SBOR0090	nullOld Strain Index: sbr07 large\n	\N	\N	\N
765	2	\N	\N	556	731	767	SBOR0091	nullOld Strain Index: sbr07 small\n	\N	\N	\N
802	2	\N	\N	561	773	737	SBOR0106	nullOld Strain Index: SBB12\nStrain Note: glossy\n	\N	\N	\N
778	2	\N	\N	\N	773	745	SBOR0096	nullOld Strain Index: SBB04\nStrain Note: smooth, translucent; cloudy\n	\N	\N	\N
788	2	\N	\N	\N	773	790	SBOR0100	nullOld Strain Index: SBB06\nStrain Note: smooth, glossy, translucent\n	\N	\N	\N
780	2	\N	\N	\N	773	782	SBOR0097	nullOld Strain Index: SBB05\nStrain Note: smooth, glossy\n	\N	\N	\N
783	2	\N	\N	\N	773	785	SBOR0098	nullOld Strain Index: sbb05 small\n	\N	\N	\N
797	2	\N	\N	124	773	737	SBOR0104	nullOld Strain Index: SBB10\nStrain Note: cloudy, translucent, rough, pebbly\n	\N	\N	\N
791	2	\N	\N	\N	773	737	SBOR0101	nullOld Strain Index: SBB07\nStrain Note: translucent, glossy\n	\N	\N	\N
793	2	\N	\N	39	773	790	SBOR0102	nullOld Strain Index: SBB08\nStrain Note: glossy, translucent\n	\N	\N	\N
795	2	\N	\N	561	773	737	SBOR0103	nullOld Strain Index: SBB09\nStrain Note: opaque, dull\n	\N	\N	\N
799	2	\N	\N	124	773	801	SBOR0105	nullOld Strain Index: SBB11\nStrain Note: transparent, smooth, slightly glossy\n	\N	\N	\N
808	2	\N	\N	\N	731	806	SBOR0108	nullOld Strain Index: A2\nStrain Note: Slightly translucent, glossy\n	\N	\N	\N
804	2	\N	\N	39	731	806	SBOR0107	nullOld Strain Index: A1\nStrain Note: Slightly translucent, glossy\n	\N	\N	\N
810	2	\N	\N	556	731	812	SBOR0109	nullOld Strain Index: B1\nStrain Note: Cloudy\n	\N	\N	\N
813	2	\N	\N	\N	731	815	SBOR0110	nullOld Strain Index: B2\nStrain Note: Cloudy\n	\N	\N	\N
816	2	\N	\N	\N	731	818	SBOR0111	nullOld Strain Index: C1\nStrain Note: gossy\n	\N	\N	\N
819	2	\N	\N	\N	731	818	SBOR0112	nullOld Strain Index: C2\nStrain Note: glossy\n	\N	\N	\N
821	2	\N	\N	43	731	818	SBOR0113	nullOld Strain Index: D1\nStrain Note: translucent, glossy\n	\N	\N	\N
823	2	\N	\N	43	731	825	SBOR0114	nullOld Strain Index: D2\nStrain Note: translucent, glossy\n	\N	\N	\N
826	2	\N	\N	\N	731	828	SBOR0115	nullOld Strain Index: E1\nStrain Note: Cloudy\n	\N	\N	\N
829	2	\N	\N	43	731	825	SBOR0116	nullOld Strain Index: E1 clear\n	\N	\N	\N
831	2	\N	\N	\N	731	806	SBOR0117	nullOld Strain Index: E1 white\n	\N	\N	\N
873	2	\N	\N	\N	872	869	SBOR0134	nullOld Strain Index: L2\nStrain Note: dusty-cloudy, excludes everything else\n	\N	\N	\N
833	2	\N	\N	\N	731	835	SBOR0118	nullOld Strain Index: E2\nStrain Species: -\nStrain Note: Cloudy\n	\N	\N	\N
836	2	\N	\N	39	731	818	SBOR0119	nullOld Strain Index: E2 clear\n	\N	\N	\N
933	2	\N	\N	\N	731	935	SBOR0157	nullOld Strain Index: CC\n	\N	\N	\N
838	2	\N	\N	\N	731	806	SBOR0120	nullOld Strain Index: E2 white\n	\N	\N	\N
875	2	\N	\N	\N	872	877	SBOR0135	nullOld Strain Index: M1\nStrain Note: cloudy, glossy\n	\N	\N	\N
840	2	\N	\N	39	731	806	SBOR0121	nullOld Strain Index: F1\nStrain Note: cloudy\n	\N	\N	\N
842	2	\N	\N	28	731	806	SBOR0122	nullOld Strain Index: F2\nStrain Note: cloudy\n	\N	\N	\N
903	2	\N	\N	\N	872	869	SBOR0146	nullOld Strain Index: R2\nStrain Note: opaque, ages cranberry\n	\N	\N	\N
844	2	\N	\N	39	731	806	SBOR0123	nullOld Strain Index: G1\nStrain Note: mottled, cloudy, film-forming, excludes A\n	\N	\N	\N
878	2	\N	\N	\N	872	869	SBOR0136	nullOld Strain Index: M2\nStrain Note: cloudy, glossy\n	\N	\N	\N
846	2	\N	\N	\N	731	806	SBOR0124	nullOld Strain Index: G2\nStrain Note: mottled, cloudy, film-forming, excludes A\n	\N	\N	\N
848	2	\N	\N	\N	731	818	SBOR0125	nullOld Strain Index: H1\nStrain Note: Whitish border\n	\N	\N	\N
850	2	\N	\N	43	731	818	SBOR0126	nullOld Strain Index: H2\nStrain Note: Whitish border\n	\N	\N	\N
880	2	\N	\N	124	872	877	SBOR0137	nullOld Strain Index: N1\nStrain Note: dusty, matte\n	\N	\N	\N
852	2	\N	\N	22	731	818	SBOR0127	nullOld Strain Index: I1\nStrain Note: transparent, smooth, slightly glossy, clear film over colonies\n	\N	\N	\N
854	2	\N	\N	22	731	856	SBOR0128	nullOld Strain Index: I2\nStrain Note: transparent, smooth, slightly glossy, clear film over colonies\n	\N	\N	\N
921	2	\N	\N	\N	731	923	SBOR0153	nullOld Strain Index: V1\nStrain Note: very matte, covers whole plate, strong nutty/fruity smell\n	\N	\N	\N
857	2	\N	\N	157	731	859	SBOR0129	nullOld Strain Index: J1\nStrain Species: cholerae\n	\N	\N	\N
882	2	\N	\N	124	872	884	SBOR0138	nullOld Strain Index: N2\nStrain Note: dusty, matte\n	\N	\N	\N
860	2	\N	\N	124	731	806	SBOR0130	nullOld Strain Index: J2\n	\N	\N	\N
862	2	\N	\N	43	731	864	SBOR0131	nullOld Strain Index: K1\nStrain Note: rough, orange-brown film\n	\N	\N	\N
905	2	\N	\N	563	910	907	SBOR0147	nullOld Strain Index: S1\nStrain Species: anguillarum\nStrain Note: very shiny, may swarm (?)\n	\N	\N	\N
865	2	\N	\N	43	731	806	SBOR0132	nullOld Strain Index: K2\nStrain Note: rough, orange-brown film\n	\N	\N	\N
885	2	\N	\N	124	872	887	SBOR0139	nullOld Strain Index: O1\nStrain Note: fibirous\n	\N	\N	\N
867	2	\N	\N	28	872	869	SBOR0133	nullOld Strain Index: L1\nStrain Note: dusty-cloudy, excludes everything else\n	\N	\N	\N
888	2	\N	\N	124	872	890	SBOR0140	nullOld Strain Index: O2\nStrain Note: fibirous\n	\N	\N	\N
891	2	\N	\N	\N	872	893	SBOR0141	nullOld Strain Index: P1\nStrain Note: fuzzy\n	\N	\N	\N
911	2	\N	\N	563	910	907	SBOR0148	nullOld Strain Index: S2\nStrain Species: anguillarum\nStrain Note: very shiny, may swarm (?)\n	\N	\N	\N
894	2	\N	\N	\N	872	896	SBOR0142	nullOld Strain Index: P2\nStrain Note: fuzzy\n	\N	\N	\N
897	2	\N	\N	561	872	869	SBOR0143	nullOld Strain Index: Q1\nStrain Note: possible Oeskovia\n	\N	\N	\N
899	2	\N	\N	561	872	869	SBOR0144	nullOld Strain Index: Q2\nStrain Note: possible Oeskovia\n	\N	\N	\N
913	2	\N	\N	\N	910	907	SBOR0149	nullOld Strain Index: T1\nStrain Note: rough, yellow/off-white film\n	\N	\N	\N
901	2	\N	\N	562	872	869	SBOR0145	nullOld Strain Index: R1\nStrain Note: opaque, ages cranberry\n	\N	\N	\N
925	2	\N	\N	\N	731	923	SBOR0154	nullOld Strain Index: V1\nStrain Note: very matte, covers whole plate, strong nutty/fruity smell\n	\N	\N	\N
915	2	\N	\N	\N	910	907	SBOR0150	nullOld Strain Index: T2\nStrain Note: rough, yellow/off-white film\n	\N	\N	\N
917	2	\N	\N	\N	910	907	SBOR0151	nullOld Strain Index: U1\n	\N	\N	\N
948	2	\N	\N	\N	872	950	SBOR0163	nullOld Strain Index: II\nStrain Note: mucoid\n	\N	\N	\N
919	2	\N	\N	\N	910	907	SBOR0152	nullOld Strain Index: U2\n	\N	\N	\N
927	2	\N	\N	\N	872	929	SBOR0155	nullOld Strain Index: AA\nStrain Note: mucoid; gloppy\n	\N	\N	\N
937	2	\N	\N	124	872	929	SBOR0158	nullOld Strain Index: DD\nStrain Note: "target"\n	\N	\N	\N
931	2	\N	\N	\N	872	929	SBOR0156	nullOld Strain Index: BB\nStrain Note: mucoid; gloppy\n	\N	\N	\N
944	2	\N	\N	124	773	943	SBOR0161	nullOld Strain Index: GG\n	\N	\N	\N
939	2	\N	\N	246	872	929	SBOR0159	nullOld Strain Index: EE\n	\N	\N	\N
941	2	\N	\N	\N	773	943	SBOR0160	nullOld Strain Index: FF\n	\N	\N	\N
946	2	\N	\N	39	872	929	SBOR0162	nullOld Strain Index: HH\n	\N	\N	\N
951	2	\N	\N	\N	872	953	SBOR0164	nullOld Strain Index: JJ\n	\N	\N	\N
954	2	\N	\N	28	731	956	SBOR0165	nullOld Strain Index: KK\n	\N	\N	\N
957	2	\N	\N	\N	731	956	SBOR0166	nullOld Strain Index: LL\n	\N	\N	\N
959	2	\N	\N	43	731	923	SBOR0167	nullOld Strain Index: MM\n	\N	\N	\N
961	2	\N	\N	39	731	956	SBOR0168	nullOld Strain Index: NN\n	\N	\N	\N
963	2	\N	\N	\N	872	950	SBOR0169	nullOld Strain Index: OO\n	\N	\N	\N
965	2	\N	\N	39	731	923	SBOR0170	nullOld Strain Index: PP\n	\N	\N	\N
967	2	\N	\N	43	731	923	SBOR0171	nullOld Strain Index: QQ\nStrain Note: mucoid\n	\N	\N	\N
969	2	\N	\N	39	731	923	SBOR0172	nullOld Strain Index: RR\n	\N	\N	\N
971	2	\N	\N	28	731	923	SBOR0173	nullOld Strain Index: SS\n	\N	\N	\N
973	2	\N	\N	28	731	956	SBOR0174	nullOld Strain Index: TT\n	\N	\N	\N
975	2	\N	\N	\N	872	977	SBOR0175	nullOld Strain Index: UU\nStrain Note: Slow in broth\n	\N	\N	\N
978	2	\N	\N	\N	872	980	SBOR0176	nullOld Strain Index: VV\nStrain Note: Slow in broth\n	\N	\N	\N
981	2	\N	\N	39	731	923	SBOR0177	nullOld Strain Index: WW\n	\N	\N	\N
983	2	\N	\N	39	731	923	SBOR0178	nullOld Strain Index: XX\n	\N	\N	\N
\.


--
-- Data for Name: strain_genotype; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY strain_genotype (id, version, name, note) FROM stdin;
\.


--
-- Name: blast_query_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY blast_query
    ADD CONSTRAINT blast_query_pkey PRIMARY KEY (id);


--
-- Name: category_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY category
    ADD CONSTRAINT category_name_key UNIQUE (name);


--
-- Name: category_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY category
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- Name: encrypted_data_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY encrypted_data
    ADD CONSTRAINT encrypted_data_pkey PRIMARY KEY (id);


--
-- Name: experiment_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY experiment
    ADD CONSTRAINT experiment_name_key UNIQUE (name);


--
-- Name: experiment_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY experiment
    ADD CONSTRAINT experiment_pkey PRIMARY KEY (id);


--
-- Name: genome_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY genome
    ADD CONSTRAINT genome_pkey PRIMARY KEY (id);


--
-- Name: genome_type_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY genome_type
    ADD CONSTRAINT genome_type_pkey PRIMARY KEY (id);


--
-- Name: genus_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY genus
    ADD CONSTRAINT genus_name_key UNIQUE (name);


--
-- Name: genus_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY genus
    ADD CONSTRAINT genus_pkey PRIMARY KEY (id);


--
-- Name: host_facility_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY host_facility
    ADD CONSTRAINT host_facility_name_key UNIQUE (name);


--
-- Name: host_facility_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY host_facility
    ADD CONSTRAINT host_facility_pkey PRIMARY KEY (id);


--
-- Name: host_genotype_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY host_genotype
    ADD CONSTRAINT host_genotype_name_key UNIQUE (name);


--
-- Name: host_genotype_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY host_genotype
    ADD CONSTRAINT host_genotype_pkey PRIMARY KEY (id);


--
-- Name: host_origin_genotypes_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY host_origin_genotypes
    ADD CONSTRAINT host_origin_genotypes_pkey PRIMARY KEY (host_origin_id, host_genotype_id);


--
-- Name: host_origin_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY host_origin
    ADD CONSTRAINT host_origin_pkey PRIMARY KEY (id);


--
-- Name: isolate_condition_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY isolate_condition
    ADD CONSTRAINT isolate_condition_pkey PRIMARY KEY (id);


--
-- Name: lab_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY lab
    ADD CONSTRAINT lab_name_key UNIQUE (name);


--
-- Name: lab_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY lab
    ADD CONSTRAINT lab_pkey PRIMARY KEY (id);


--
-- Name: location_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY location
    ADD CONSTRAINT location_name_key UNIQUE (name);


--
-- Name: location_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY location
    ADD CONSTRAINT location_pkey PRIMARY KEY (id);


--
-- Name: measured_value_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY measured_value
    ADD CONSTRAINT measured_value_pkey PRIMARY KEY (id);


--
-- Name: phylum_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY phylum
    ADD CONSTRAINT phylum_name_key UNIQUE (name);


--
-- Name: phylum_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY phylum
    ADD CONSTRAINT phylum_pkey PRIMARY KEY (id);


--
-- Name: population_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY population
    ADD CONSTRAINT population_pkey PRIMARY KEY (id);


--
-- Name: researcher_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY researcher
    ADD CONSTRAINT researcher_pkey PRIMARY KEY (id);


--
-- Name: researcher_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY researcher_roles
    ADD CONSTRAINT researcher_roles_pkey PRIMARY KEY (researcher_id, role_id);


--
-- Name: researcher_username_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY researcher
    ADD CONSTRAINT researcher_username_key UNIQUE (username);


--
-- Name: role_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY role
    ADD CONSTRAINT role_name_key UNIQUE (name);


--
-- Name: role_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- Name: species_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY species
    ADD CONSTRAINT species_pkey PRIMARY KEY (id);


--
-- Name: stock_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY stock
    ADD CONSTRAINT stock_pkey PRIMARY KEY (id);


--
-- Name: strain_genotype_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY strain_genotype
    ADD CONSTRAINT strain_genotype_name_key UNIQUE (name);


--
-- Name: strain_genotype_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY strain_genotype
    ADD CONSTRAINT strain_genotype_pkey PRIMARY KEY (id);


--
-- Name: strain_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY strain
    ADD CONSTRAINT strain_name_key UNIQUE (name);


--
-- Name: strain_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY strain
    ADD CONSTRAINT strain_pkey PRIMARY KEY (id);


--
-- Name: fk4a55fc986fbfb972; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY host_origin_genotypes
    ADD CONSTRAINT fk4a55fc986fbfb972 FOREIGN KEY (host_genotype_id) REFERENCES host_genotype(id);


--
-- Name: fk4a55fc98e9ff052; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY host_origin_genotypes
    ADD CONSTRAINT fk4a55fc98e9ff052 FOREIGN KEY (host_origin_id) REFERENCES host_origin(id);


--
-- Name: fk5db09ee5c83c4c1; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY genus
    ADD CONSTRAINT fk5db09ee5c83c4c1 FOREIGN KEY (phylum_id) REFERENCES phylum(id);


--
-- Name: fk68af71677e9e381; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY stock
    ADD CONSTRAINT fk68af71677e9e381 FOREIGN KEY (strain_id) REFERENCES strain(id);


--
-- Name: fk68af716e9e8a8ea; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY stock
    ADD CONSTRAINT fk68af716e9e8a8ea FOREIGN KEY (general_location_id) REFERENCES location(id);


--
-- Name: fk7ad8899d2aa7ad32; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY host_origin
    ADD CONSTRAINT fk7ad8899d2aa7ad32 FOREIGN KEY (host_facility_id) REFERENCES host_facility(id);


--
-- Name: fk7ad8899d3e012901; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY host_origin
    ADD CONSTRAINT fk7ad8899d3e012901 FOREIGN KEY (population_id) REFERENCES population(id);


--
-- Name: fk7ad8899d4f9e7333; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY host_origin
    ADD CONSTRAINT fk7ad8899d4f9e7333 FOREIGN KEY (species_id) REFERENCES species(id);


--
-- Name: fk7cabd388dfb5aa13; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY researcher
    ADD CONSTRAINT fk7cabd388dfb5aa13 FOREIGN KEY (lab_id) REFERENCES lab(id);


--
-- Name: fk8849413caa96c833; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY species
    ADD CONSTRAINT fk8849413caa96c833 FOREIGN KEY (genus_id) REFERENCES genus(id);


--
-- Name: fk9627ff463eeffb21; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY researcher_roles
    ADD CONSTRAINT fk9627ff463eeffb21 FOREIGN KEY (researcher_id) REFERENCES researcher(id);


--
-- Name: fk9627ff466cdb45a1; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY researcher_roles
    ADD CONSTRAINT fk9627ff466cdb45a1 FOREIGN KEY (role_id) REFERENCES role(id);


--
-- Name: fka6a21a4d3eeffb21; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY researcher_permissions
    ADD CONSTRAINT fka6a21a4d3eeffb21 FOREIGN KEY (researcher_id) REFERENCES researcher(id);


--
-- Name: fkac5e95cd33ae8d18; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY species_host_genotype
    ADD CONSTRAINT fkac5e95cd33ae8d18 FOREIGN KEY (species_genotypes_id) REFERENCES species(id);


--
-- Name: fkac5e95cd6fbfb972; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY species_host_genotype
    ADD CONSTRAINT fkac5e95cd6fbfb972 FOREIGN KEY (host_genotype_id) REFERENCES host_genotype(id);


--
-- Name: fkb5861cf770e62030; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY genome
    ADD CONSTRAINT fkb5861cf770e62030 FOREIGN KEY (genome_type_id) REFERENCES genome_type(id);


--
-- Name: fkb5861cf777e9e381; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY genome
    ADD CONSTRAINT fkb5861cf777e9e381 FOREIGN KEY (strain_id) REFERENCES strain(id);


--
-- Name: fkb8302e871afcfd4c; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY isolate_condition
    ADD CONSTRAINT fkb8302e871afcfd4c FOREIGN KEY (isolated_by_id) REFERENCES researcher(id);


--
-- Name: fkcad5417529128baa; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY strain
    ADD CONSTRAINT fkcad5417529128baa FOREIGN KEY (isolate_condition_id) REFERENCES isolate_condition(id);


--
-- Name: fkcad541754f8a9a2c; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY strain
    ADD CONSTRAINT fkcad541754f8a9a2c FOREIGN KEY (parent_strain_id) REFERENCES strain(id);


--
-- Name: fkcad54175aa96c833; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY strain
    ADD CONSTRAINT fkcad54175aa96c833 FOREIGN KEY (genus_id) REFERENCES genus(id);


--
-- Name: fkcad54175e9ff052; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY strain
    ADD CONSTRAINT fkcad54175e9ff052 FOREIGN KEY (host_origin_id) REFERENCES host_origin(id);


--
-- Name: fkcad54175f42a5acc; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY strain
    ADD CONSTRAINT fkcad54175f42a5acc FOREIGN KEY (strain_genotype_id) REFERENCES strain_genotype(id);


--
-- Name: fkcc54eb877e9e381; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY measured_value
    ADD CONSTRAINT fkcc54eb877e9e381 FOREIGN KEY (strain_id) REFERENCES strain(id);


--
-- Name: fkcc54eb8aec16d21; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY measured_value
    ADD CONSTRAINT fkcc54eb8aec16d21 FOREIGN KEY (category_id) REFERENCES category(id);


--
-- Name: fkcc54eb8b2082b01; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY measured_value
    ADD CONSTRAINT fkcc54eb8b2082b01 FOREIGN KEY (experiment_id) REFERENCES experiment(id);


--
-- Name: fkead9d23b6cdb45a1; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY role_permissions
    ADD CONSTRAINT fkead9d23b6cdb45a1 FOREIGN KEY (role_id) REFERENCES role(id);


--
-- Name: fkfae9dbfd3eeffb21; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY experiment
    ADD CONSTRAINT fkfae9dbfd3eeffb21 FOREIGN KEY (researcher_id) REFERENCES researcher(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

