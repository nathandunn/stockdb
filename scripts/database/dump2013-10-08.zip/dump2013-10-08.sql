--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: category; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE category (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    note character varying(255),
    type character varying(255),
    units character varying(255)
);


ALTER TABLE public.category OWNER TO ndunn;

--
-- Name: encrypted_data; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE encrypted_data (
    id character varying(32) NOT NULL,
    version bigint NOT NULL,
    data_item character varying(512)
);


ALTER TABLE public.encrypted_data OWNER TO ndunn;

--
-- Name: experiment; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE experiment (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    note character varying(255),
    researcher_id bigint,
    when_performed timestamp without time zone
);


ALTER TABLE public.experiment OWNER TO ndunn;

--
-- Name: genome; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE genome (
    id bigint NOT NULL,
    version bigint NOT NULL,
    external_id character varying(255) NOT NULL,
    genome_type_id bigint NOT NULL,
    genome_version real,
    note character varying(255),
    quality integer,
    size real,
    strain_id bigint
);


ALTER TABLE public.genome OWNER TO ndunn;

--
-- Name: genome_type; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE genome_type (
    id bigint NOT NULL,
    version bigint NOT NULL,
    base_url character varying(255) NOT NULL,
    organization_name character varying(255) NOT NULL
);


ALTER TABLE public.genome_type OWNER TO ndunn;

--
-- Name: genus; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE genus (
    id bigint NOT NULL,
    version bigint NOT NULL,
    host boolean,
    name character varying(255) NOT NULL,
    phylum_id bigint NOT NULL
);


ALTER TABLE public.genus OWNER TO ndunn;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: ndunn
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO ndunn;

--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: ndunn
--

SELECT pg_catalog.setval('hibernate_sequence', 554, true);


--
-- Name: host_facility; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE host_facility (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.host_facility OWNER TO ndunn;

--
-- Name: host_genotype; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE host_genotype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    zfin_id character varying(255)
);


ALTER TABLE public.host_genotype OWNER TO ndunn;

--
-- Name: host_origin; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE host_origin (
    id bigint NOT NULL,
    version bigint NOT NULL,
    anatomy character varying(255),
    anatomy_url character varying(255),
    days_past_fertilization integer,
    host_facility_id bigint NOT NULL,
    notes character varying(255),
    species_id bigint NOT NULL,
    stage character varying(255)
);


ALTER TABLE public.host_origin OWNER TO ndunn;

--
-- Name: host_origin_genotypes; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE host_origin_genotypes (
    host_genotype_id bigint NOT NULL,
    host_origin_id bigint NOT NULL
);


ALTER TABLE public.host_origin_genotypes OWNER TO ndunn;

--
-- Name: isolate_condition; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE isolate_condition (
    id bigint NOT NULL,
    version bigint NOT NULL,
    isolated_by_id bigint,
    isolated_when timestamp without time zone NOT NULL,
    media character varying(255),
    notes character varying(255),
    oxygen_condition character varying(255),
    temperature real
);


ALTER TABLE public.isolate_condition OWNER TO ndunn;

--
-- Name: lab; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE lab (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.lab OWNER TO ndunn;

--
-- Name: location; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE location (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.location OWNER TO ndunn;

--
-- Name: measured_value; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE measured_value (
    id bigint NOT NULL,
    version bigint NOT NULL,
    category_id bigint NOT NULL,
    experiment_id bigint NOT NULL,
    strain_id bigint NOT NULL,
    type character varying(255),
    value character varying(255) NOT NULL
);


ALTER TABLE public.measured_value OWNER TO ndunn;

--
-- Name: phylum; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE phylum (
    id bigint NOT NULL,
    version bigint NOT NULL,
    host boolean,
    name character varying(255) NOT NULL
);


ALTER TABLE public.phylum OWNER TO ndunn;

--
-- Name: researcher; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE researcher (
    id bigint NOT NULL,
    version bigint NOT NULL,
    first_name character varying(255) NOT NULL,
    lab_id bigint,
    last_name character varying(255) NOT NULL,
    password_hash character varying(255),
    username character varying(255)
);


ALTER TABLE public.researcher OWNER TO ndunn;

--
-- Name: researcher_permissions; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE researcher_permissions (
    researcher_id bigint,
    permissions_string character varying(255)
);


ALTER TABLE public.researcher_permissions OWNER TO ndunn;

--
-- Name: researcher_roles; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE researcher_roles (
    researcher_id bigint NOT NULL,
    role_id bigint NOT NULL
);


ALTER TABLE public.researcher_roles OWNER TO ndunn;

--
-- Name: role; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE role (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.role OWNER TO ndunn;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE role_permissions (
    role_id bigint,
    permissions_string character varying(255)
);


ALTER TABLE public.role_permissions OWNER TO ndunn;

--
-- Name: species; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE species (
    id bigint NOT NULL,
    version bigint NOT NULL,
    common_name character varying(255),
    genus_id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.species OWNER TO ndunn;

--
-- Name: species_host_genotype; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE species_host_genotype (
    species_genotypes_id bigint,
    host_genotype_id bigint
);


ALTER TABLE public.species_host_genotype OWNER TO ndunn;

--
-- Name: stock; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE stock (
    id bigint NOT NULL,
    version bigint NOT NULL,
    box_index integer NOT NULL,
    box_number integer NOT NULL,
    general_location_id bigint,
    strain_id bigint
);


ALTER TABLE public.stock OWNER TO ndunn;

--
-- Name: strain; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE strain (
    id bigint NOT NULL,
    version bigint NOT NULL,
    date_entered timestamp without time zone,
    former_clone_alias character varying(255),
    genus_id bigint,
    host_origin_id bigint,
    isolate_condition_id bigint,
    name character varying(255) NOT NULL,
    notes text,
    parent_strain_id bigint,
    strain_genotype_id bigint
);


ALTER TABLE public.strain OWNER TO ndunn;

--
-- Name: strain_genotype; Type: TABLE; Schema: public; Owner: ndunn; Tablespace: 
--

CREATE TABLE strain_genotype (
    id bigint NOT NULL,
    version bigint NOT NULL,
    name character varying(255) NOT NULL,
    note character varying(255)
);


ALTER TABLE public.strain_genotype OWNER TO ndunn;

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY category (id, version, name, note, type, units) FROM stdin;
390	0	Motility	\N	TEXT	\N
392	0	HemolyticActivity	\N	TEXT	\N
394	0	Antibiotic	\N	TEXT	\N
396	0	Doubling Time	\N	DECIMAL	\N
398	0	Adherence	\N	TEXT	\N
550	0	color	\N	TEXT	\N
551	0	colony shape	\N	TEXT	\N
\.


--
-- Data for Name: encrypted_data; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY encrypted_data (id, version, data_item) FROM stdin;
\.


--
-- Data for Name: experiment; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY experiment (id, version, name, note, researcher_id, when_performed) FROM stdin;
391	0	Motility 1	\N	\N	\N
393	0	HemolyticActivity 1	\N	\N	\N
395	0	Antibiotic 1	\N	\N	\N
397	0	Doubling Time 1	\N	\N	\N
399	0	Adherence 1	\N	\N	\N
549	0	Colony morphology	\N	8	2013-10-03 00:00:00
\.


--
-- Data for Name: genome; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY genome (id, version, external_id, genome_type_id, genome_version, note, quality, size, strain_id) FROM stdin;
34	0	68767	16	\N	\N	294	4443477	29
37	0	40453	16	\N	\N	714	4585056	36
69	0	56182	16	\N	\N	169	4127210	67
81	0	56183	16	\N	\N	152	3836772	79
85	0	55103	16	\N	\N	89	4964650	83
94	0	56184	16	\N	\N	418	4850524	92
114	0	56185	16	\N	\N	120	3732217	113
118	0	56190	16	\N	\N	480	3018275	117
204	0	56176	16	\N	\N	4049	8473200	202
219	0	62910	16	\N	\N	1196	4938611	217
222	0	62911	16	\N	\N	280	5139916	221
240	0	63408	16	\N	\N	199	2754751	239
244	0	68768	16	\N	\N	48	2688105	242
214	1	62909	16	\N	\N	309	6946308	213
280	2	18633	16	1	\N	203	4667646	279
231	1	40452	16	\N	\N	99	3332121	229
227	1	68766	16	\N	\N	831	5313894	224
237	1	63407	16	\N	\N	250	4039019	236
497	0	2526164559	496	1	\N	\N	\N	49
498	0	2526164558	496	1	\N	\N	\N	56
499	0	2526164725	496	\N	\N	\N	\N	73
500	0	2526164726	496	\N	\N	\N	\N	105
501	0	2528311003	496	\N	\N	\N	\N	109
502	0	2528311001	496	\N	\N	\N	\N	153
503	0	2524614720	496	\N	\N	\N	\N	158
504	0	2528311002	496	\N	\N	\N	\N	206
505	0	2528311000	496	\N	\N	\N	\N	209
506	0	2526164727	496	\N	\N	\N	\N	234
507	0	2526164560	496	\N	\N	\N	\N	29
508	0	2526164561	496	\N	\N	\N	\N	36
509	0	2526164562	496	\N	\N	\N	\N	67
510	0	2526164564	496	\N	\N	\N	\N	79
511	0	2526164563	496	\N	\N	\N	\N	83
512	0	2526164565	496	\N	\N	\N	\N	92
513	0	2526164566	496	\N	\N	\N	\N	113
514	0	2526164567	496	\N	\N	\N	\N	117
515	0	2526164568	496	\N	\N	\N	\N	202
516	0	2526164570	496	\N	\N	\N	\N	213
517	0	2526164571	496	\N	\N	\N	\N	217
518	0	2526164569	496	\N	\N	\N	\N	221
519	0	2526164572	496	\N	\N	\N	\N	224
520	0	2526164575	496	\N	\N	\N	\N	229
521	0	2522572152	496	\N	\N	\N	\N	236
522	0	2526164573	496	\N	\N	\N	\N	242
523	0	2526164574	496	\N	\N	\N	\N	239
524	0	89994	16	1	\N	53	2837761	49
525	0	89995	16	1	\N	109	1966916	56
526	0	89996	16	1	\N	142	4445381	73
527	0	89997	16	1	\N	71	3478413	105
528	0	89538	16	1	\N	211	4074318	109
529	0	89543	16	\N	\N	126	2738438	153
530	0	89539	16	\N	\N	53	2837761	158
531	0	89542	16	1	\N	173	5926449	206
532	0	89541	16	1	\N	1007	6362002	209
533	0	89999	16	1	\N	149	2235296	234
\.


--
-- Data for Name: genome_type; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY genome_type (id, version, base_url, organization_name) FROM stdin;
16	0	http://rast.nmpdr.org/rast.cgi?page=JobDetails&job=	Rast
17	0	http://www.ncbi.nlm.nih.gov/bioproject/	NCBI BioProject
496	0	https://img.jgi.doe.gov/cgi-bin/er/main.cgi?section=TaxonDetail&page=taxonDetail&taxon_oid=	IMG
\.


--
-- Data for Name: genus; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY genus (id, version, host, name, phylum_id) FROM stdin;
19	1	t	Danio	18
22	0	f	Plesiomonas	21
28	0	f	Aeromonas	21
39	0	f	Pseudomonas	21
43	0	f	Shewanella	21
48	0	f	Exiguobacterium	47
55	0	f	Haloplasma	54
66	0	f	Acinetobacter	21
72	0	f	Nubsella	71
88	0	f	Chitinibacter	87
91	0	f	Enterobacter	21
97	0	f	Cetobacterium	96
101	0	f	Staphylococcus	47
108	0	f	Vibrio/Listonella	21
112	0	f	Microbacterium	111
116	0	f	Kocuria	111
120	0	f	Comamonas	87
124	0	f	Bacillus	47
127	0	f	Chryseobacterium	71
157	0	f	Vibrio	21
190	0	f	Propionibacterium	111
194	0	f	Dermacoccus	111
201	0	f	Variovorax	87
208	0	f	Delftia	87
212	0	f	Ensifer/Sinorhizobium	211
216	0	f	Bosea	211
233	0	f	Carnobacterium	47
246	0	f	Cellulomonas	111
263	0	f	Enterococcus	47
266	0	f	Proteus	249
282	0	f	Citrobacter	249
287	0	f	Clostridium	47
328	0	f	unclassified Comamonadaceae	87
349	0	f	Shinella	87
359	0	f	Ensifer	211
364	0	f	Mycobacterium	111
537	0	f	unclassified	47
554	0	t	Gasterosteus	18
\.


--
-- Data for Name: host_facility; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY host_facility (id, version, name) FROM stdin;
30	13	University of Oregon
218	0	University of North Carolina
24	1	Washington University
\.


--
-- Data for Name: host_genotype; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY host_genotype (id, version, name, zfin_id) FROM stdin;
31	0	WT	\N
50	0	ABxTu	\N
57	0	ABCxTu	\N
62	0	ABxTu; Tank D from Longitudinal Study 2011	\N
76	0	ABC-7	\N
154	0	ABC-07	\N
\.


--
-- Data for Name: host_origin; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY host_origin (id, version, anatomy, anatomy_url, days_past_fertilization, host_facility_id, notes, species_id, stage) FROM stdin;
32	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	0	30	\N	20	Larval
51	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	14	30	\N	20	14dpf
58	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	21	30	\N	20	21dpf
63	2	\N	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	360	30	\N	20	1 year old
68	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	90	30	\N	20	Adult
80	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	28	30	\N	20	28dpf
84	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	6	30	\N	20	6dpf
122	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	12	30	\N	20	12dpf
133	1	\N	\N	4	30	\N	20	4dpf
77	3	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	60	30	\N	20	60dpf
161	2	\N	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	360	30	\N	20	1 year old
164	2	\N	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	360	30	\N	20	1 year old
192	2	\N	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	360	30	\N	20	1 year old
225	2	Intestine	http://zfin.org/action/ontology/term-detail/ZDB-TERM-100331-1295	90	24	\N	20	Adult
130	2	\N	\N	3	30	\N	20	null
\.


--
-- Data for Name: host_origin_genotypes; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY host_origin_genotypes (host_genotype_id, host_origin_id) FROM stdin;
31	32
50	51
57	58
62	63
31	68
31	80
31	84
31	122
154	77
62	161
62	164
62	192
31	225
\.


--
-- Data for Name: isolate_condition; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY isolate_condition (id, version, isolated_by_id, isolated_when, media, notes, oxygen_condition, temperature) FROM stdin;
33	1	\N	1901-01-01 00:00:00	LB / TSA	null\n	Aerobic	30
41	0	\N	1901-01-01 00:00:00	BHI / LB / TSA	null	Aerobic	30
59	1	3	2013-05-07 00:00:00	BHI+Polymyxin B (1000 units/mL)	null	Aerobic	30
45	2	3	2012-07-09 00:00:00	TSA	null\n	Aerobic	30
103	1	3	2012-07-09 00:00:00	BHI / TSA / NA	null	Anaerobic	30
64	4	3	2013-11-07 00:00:00	BHI+Polymyxin B (1000 units/mL)	null\n\n\n	Anaerobic	30
106	8	3	2012-09-11 00:00:00	BHI	null Sonicated gut for 4 min\n Sonicated gut for 4 min\n Sonicated gut for 4 min\n\n\n Sonicated gut for 4 min	Aerobic	30
93	11	3	2011-09-09 00:00:00	NA/M17	null\n\n\n\n\n\n\n\n\n\n	Aerobic	30
226	0	\N	1901-01-01 00:00:00	BHI/LB/TSA	null	Aerobic	30
230	0	\N	1901-01-01 00:00:00	BHI / LB	null	Aerobic	30
25	6	3	1901-01-01 00:00:00	BHI / TSA	null\n\n\n\n	Aerobic	30
99	5	3	1901-01-01 00:00:00	BHI / TSA	null\n\n\n\n	Anaerobic	30
243	0	\N	1901-01-01 00:00:00	BHI / TSA	null	Microaerophilic / Aerobic	30
155	4	3	2013-11-07 00:00:00	Fastidious Anaerobe Agar + 5% Blood	null  	Anaerobic	30
52	8	3	2013-05-07 00:00:00	Fastidious Anaerobe Agar + 5% Blood	null      	Aerobic	30
\.


--
-- Data for Name: lab; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY lab (id, version, name) FROM stdin;
15	0	Guillemin
539	0	Eisen
\.


--
-- Data for Name: location; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY location (id, version, name) FROM stdin;
248	57	Rawls -80C Freezer
366	7	Rawls lab -80C freezer
380	1	Rawls Lab -80C Freezer
382	4	Rawls lab -80C
27	66	Guillemin -80 C Freezer
\.


--
-- Data for Name: measured_value; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY measured_value (id, version, category_id, experiment_id, strain_id, type, value) FROM stdin;
400	0	390	391	29	TEXT	motile
401	0	392	393	29	TEXT	Beta Hemolysis
402	0	394	395	29	TEXT	Kan resistant(100ug/ml)
403	0	396	397	29	TEXT	24.38
404	0	398	399	29	TEXT	-
406	0	390	391	36	TEXT	motile
407	0	392	393	36	TEXT	Beta Hemolysis
408	0	394	395	36	TEXT	Kan resistant(100ug/ml), Rif sensitive(100ug/ml), Gn sensitive (110ug/ml), CAM sensitive (10ug/ml), TC sensitive (100ug/ml)
409	0	396	397	36	TEXT	23.03
410	0	398	399	36	TEXT	-
411	0	394	395	56	TEXT	Polymyxin B resistant (1000 units/mL)
412	0	394	395	61	TEXT	Polymyxin B resistant (1000 units/mL)
413	0	390	391	67	TEXT	motile (twitch)
414	0	392	393	67	TEXT	Beta Hemolysis
415	0	394	395	67	TEXT	Rif Sens. (100 ug/mL-ZS); Kan Sens. (50 ug/mL-ZS); Trimethoprim Resist. (100 ug/mL-ZS); Chloramphenicol Resist. (20 ug/mL-ZS); Gentamycin Sens. (10 ug/mL - ZS)
416	0	396	397	67	TEXT	24.92
417	0	398	399	67	TEXT	+
418	0	394	395	73	TEXT	Polymyxin B resistant (1000 units/mL)
419	0	390	391	79	TEXT	motile
420	0	392	393	79	TEXT	Beta hemolysis
421	0	394	395	79	TEXT	Kan Sensitive (100ug/ml)
422	0	396	397	79	TEXT	27.32
423	0	398	399	79	TEXT	+
424	0	390	391	83	TEXT	motile
425	0	392	393	83	TEXT	Beta Hemolysis
426	0	394	395	83	TEXT	Rif Sens. (100 ug/mL-ZS); Kan Sens. (50 ug/mL-ZS); Kan Sens. (100 ug/mL - ZS); Trimethoprim Sens. (100 ug/mL-ZS); Chloramphenicol Sens. (20 ug/mL-ZS); Gentamycin Sens. (10 ug/mL - ZS)
427	0	396	397	83	TEXT	30.62
428	0	398	399	83	TEXT	+
429	0	390	391	92	TEXT	motile
430	0	392	393	92	TEXT	Beta Hemolysis
431	0	394	395	92	TEXT	Kan Sensitive (100ug/ml), Rif sensitive(100ug/ml), Gn sensitive (110ug/ml), CAM sensitive (10ug/ml), TC resistant (100ug/ml)
432	0	396	397	92	TEXT	30.58
433	0	398	399	92	TEXT	+
434	0	390	391	102	TEXT	non-motile
435	0	392	393	102	TEXT	Beta Hemolysis and alpha hemolysis (in oxygen labile pocket)
436	0	390	391	105	TEXT	motile
437	0	392	393	105	TEXT	(in oxygen labile pocket) alpha hemolysis
438	0	396	397	105	TEXT	31.53
439	0	398	399	105	TEXT	+
440	0	390	391	109	TEXT	motile
441	0	392	393	109	TEXT	Beta Hemolysis
442	0	390	391	113	TEXT	non-motile
443	0	392	393	113	TEXT	Beta Hemolysis
444	0	394	395	113	TEXT	Rif Sens. (100 ug/mL-ZS); Kan Resist. (50 ug/mL-ZS); Kan Sens. (100 ug/mL - ZS); Trimethoprim Sens. (100 ug/mL-ZS); Chloramphenicol Sens. (20 ug/mL = some growth, 40 ug/mL = NO growth after 2 days-ZS); Gentamycin Resist. (10 ug/mL - ZS)
445	0	396	397	113	TEXT	38.04
446	0	398	399	113	TEXT	-
447	0	390	391	117	TEXT	non-motile
448	0	392	393	117	TEXT	Beta Hemolysis and alpha hemolysis (in oxygen labile pocket)
449	0	398	399	117	TEXT	+
450	0	394	395	163	TEXT	Polymyxin B resistant (1000 units/mL)
451	0	394	395	166	TEXT	Polymyxin B resistant (1000 units/mL)
452	0	392	393	188	TEXT	Beta Hemolysis
453	0	390	391	202	TEXT	motile
454	0	392	393	202	TEXT	Gamma (non-hemolytic)
455	0	396	397	202	TEXT	37.17
456	0	398	399	202	TEXT	+
457	0	390	391	206	TEXT	motile
458	0	392	393	206	TEXT	Gamma (non-hemolytic)
459	0	396	397	206	TEXT	34.22
460	0	398	399	206	TEXT	+
461	0	390	391	209	TEXT	motile
462	0	392	393	209	TEXT	Gamma (non-hemolytic)
463	0	396	397	209	TEXT	30.74
464	0	398	399	209	TEXT	+
465	0	390	391	213	TEXT	motile
466	0	392	393	213	TEXT	Gamma (non-hemolytic)
467	0	396	397	213	TEXT	33.45
468	0	398	399	213	TEXT	+
469	0	390	391	217	TEXT	non-motile
470	0	392	393	217	TEXT	Gamma (non-hemolytic)
471	0	396	397	217	TEXT	30.09
472	0	398	399	217	TEXT	+
473	0	390	391	221	TEXT	motile
474	0	392	393	221	TEXT	Gamma (non-hemolytic)
475	0	394	395	221	TEXT	Kan resistant(100ug/ml)
476	0	396	397	221	TEXT	27.05
477	0	398	399	221	TEXT	+
478	0	390	391	224	TEXT	motile
479	0	392	393	224	TEXT	Gamma (non-hemolytic)
480	0	396	397	224	TEXT	32.83
481	0	398	399	224	TEXT	-
482	0	390	391	229	TEXT	motile
483	0	392	393	229	TEXT	Gamma (non-hemolytic)
484	0	396	397	229	TEXT	26.56
485	0	398	399	229	TEXT	+
486	0	390	391	234	TEXT	non-motile
487	0	392	393	234	TEXT	Gamma (non-hemolytic)
488	0	396	397	234	TEXT	47.74 (?)
489	0	398	399	234	TEXT	-
490	0	390	391	236	TEXT	motile
491	0	392	393	236	TEXT	Beta Hemolysis (Aerobic and in oxygen labile pocket)
492	0	394	395	236	TEXT	Kan sensitive(100ug/ml)
493	0	396	397	236	TEXT	30.96
494	0	398	399	236	TEXT	-
\.


--
-- Data for Name: phylum; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY phylum (id, version, host, name) FROM stdin;
21	0	f	Proteobacteria (gamma)
18	1	t	Chordata
47	0	f	Firmicutes
54	0	f	Tenericutes (Mollicutes)
71	0	f	Bacteroidetes
87	0	f	Proteobacteria (beta)
96	0	f	Fusobacteria
111	0	f	Actinobacteria
211	0	f	Proteobacteria (alpha)
249	0	f	Proteobacteria
\.


--
-- Data for Name: researcher; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY researcher (id, version, first_name, lab_id, last_name, password_hash, username) FROM stdin;
4	0	Travis	\N	Carney	ef09602427d453890bd1d94ddfb177ba6ae23913f2728b1377a7dcf8c25c92bb	tcarney@uoregon.edu
10	0	Mark	\N	Currey	ef09602427d453890bd1d94ddfb177ba6ae23913f2728b1377a7dcf8c25c92bb	mcurrey@uoregon.edu
14	0	Emily	\N	Schwarz	ef09602427d453890bd1d94ddfb177ba6ae23913f2728b1377a7dcf8c25c92bb	eshwarz@cs.uoregon.edu
5	1	Robert	15	Steury	ef09602427d453890bd1d94ddfb177ba6ae23913f2728b1377a7dcf8c25c92bb	steury@uoregon.edu
9	1	Zac	15	Stephens	ef09602427d453890bd1d94ddfb177ba6ae23913f2728b1377a7dcf8c25c92bb	wzacs1@gmail.com
3	3	Adam	15	Burns	93a2f72854b3da0c194df16600ae2975a93cee8cc8501a85489b09ba104c985e	aburns2@uoregon.edu
495	1	Emily	15	Sweeney	b124e30084366ed9c38295cb696bba5ecf100192efc30af46367826642b3cb50	egoers@uoregon.edu
538	1	Travis	15	Wiles	35a5ea9db6c0b4a0e946902c33e1759a9156c50fd3678078d5c6628a6ec62722	twiles@uoregon.edu
8	4	Chris	15	Wreden	d3314e003ac3e6e83ab9d6337c46b0f69e78bfc5045a01d5b66efabbba12826b	cwreden@uoregon.edu
540	3	Judith	539	Eisen	f2c8d25d138778631cec18c8b53e76a123bcaeece0fadb8aced12ed821c65904	eisen@uoneuro.uoregon.edu
536	2	Nick	\N	Stiffler	fce425c7d9c83c7391dc77c1483df9fd78a77092bb66e01458da26d31cb25f38	nstiffle@uoregon.edu
544	2	John	\N	Conery	ef09602427d453890bd1d94ddfb177ba6ae23913f2728b1377a7dcf8c25c92bb	conery@uoregon.edu
545	2	Kathy	15	Milligan-Myhre	b124e30084366ed9c38295cb696bba5ecf100192efc30af46367826642b3cb50	kmilliga@uoregon.edu
6	1	Nathan	\N	Dunn	dc7bab77cb868f6da7ec89ec81acb4ed2b609b8f3b0d5cf12146a51363139a50	ndunn@cas.uoregon.edu
7	3	Test	\N	Me	22ff0aa7343073d017343833f4dd0d70438b58f348bc97490f9a0bc04efcd4ed	ndunn@me.com
\.


--
-- Data for Name: researcher_permissions; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY researcher_permissions (researcher_id, permissions_string) FROM stdin;
\.


--
-- Data for Name: researcher_roles; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY researcher_roles (researcher_id, role_id) FROM stdin;
4	1
5	1
10	1
14	1
9	1
536	1
536	2
3	1
495	2
538	2
8	1
540	2
544	1
545	1
6	1
7	1
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY role (id, version, name) FROM stdin;
2	11	User
1	8	Administrator
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY role_permissions (role_id, permissions_string) FROM stdin;
1	*:*
2	experiment:edit
2	*:show
2	researcher:update
2	experiment:update
2	researcher:edit
2	strain:addFilter
2	*:list
2	strain:showFilter
\.


--
-- Data for Name: species; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY species (id, version, common_name, genus_id, name) FROM stdin;
20	1	Zebrafish	19	rerio
553	1	Stickleback	554	aculeatus
\.


--
-- Data for Name: species_host_genotype; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY species_host_genotype (species_genotypes_id, host_genotype_id) FROM stdin;
\.


--
-- Data for Name: stock; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY stock (id, version, box_index, box_number, general_location_id, strain_id) FROM stdin;
35	1	1	1	27	29
38	1	2	1	27	36
42	1	2147483647	2147483647	27	40
46	1	2147483647	2147483647	27	44
53	1	5	1	27	49
60	1	6	1	27	56
65	1	7	1	27	61
70	1	8	1	27	67
74	1	9	1	27	73
78	1	10	1	27	75
82	1	11	1	27	79
86	1	12	1	27	83
90	1	13	1	27	89
95	1	14	1	27	92
100	1	15	1	27	98
104	1	16	1	27	102
107	1	17	1	27	105
110	1	18	1	27	109
115	1	19	1	27	113
119	1	20	1	27	117
123	1	21	1	27	121
126	1	22	1	27	125
131	1	23	1	27	128
134	1	24	1	27	132
136	1	25	1	27	135
138	1	26	1	27	137
140	1	27	1	27	139
142	1	28	1	27	141
144	1	29	1	27	143
146	1	30	1	27	145
148	1	31	1	27	147
150	1	32	1	27	149
152	1	33	1	27	151
156	1	34	1	27	153
159	1	35	1	27	158
162	1	36	1	27	160
165	1	37	1	27	163
167	1	38	1	27	166
169	1	39	1	27	168
171	1	40	1	27	170
173	1	41	1	27	172
175	1	42	1	27	174
177	1	43	1	27	176
179	1	44	1	27	178
181	1	45	1	27	180
183	1	46	1	27	182
185	1	47	1	27	184
187	1	48	1	27	186
189	1	49	1	27	188
193	1	50	1	27	191
196	1	51	1	27	195
198	1	52	1	27	197
200	1	53	1	27	199
205	1	54	1	27	202
207	1	55	1	27	206
210	1	56	1	27	209
215	1	58	1	27	213
220	1	59	1	27	217
223	1	60	1	27	221
228	1	61	1	27	224
232	1	62	1	27	229
235	1	57	1	27	234
238	1	63	1	27	236
241	1	65	1	27	239
245	1	64	1	27	242
26	2	23	1	27	\N
\.


--
-- Data for Name: strain; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY strain (id, version, date_entered, former_clone_alias, genus_id, host_origin_id, isolate_condition_id, name, notes, parent_strain_id, strain_genotype_id) FROM stdin;
242	3	\N	ZF1NF03, Z10 (Zac)	101	225	243	ZWU0021	\N	\N	\N
239	6	\N	ZF1NH01, Z09 (Zac)	97	225	99	ZWU0022	Able to grow on BHI plate, but not in BHI liquid culture (both anaerobic)-CCW 8-22-13	\N	\N
36	2	\N	TC022	28	32	33	ZOR0002	Passaged once from original TC collection isolated by Travis Carney	\N	\N
40	1	\N	TC023	39	32	41	ZOR0003		\N	\N
44	1	\N	TC020	43	32	45	ZOR0004		\N	\N
73	3	2013-09-08 00:00:00	ZI6-37	72	58	64	ZOR0009	Can't grow from stock (anaerobic BHI agar, 30C)	\N	\N
141	2	2012-09-12 00:00:00	M17-04	28	84	93	ZOR0028		\N	\N
61	2	2013-09-08 00:00:00	ZI6-36	55	63	64	ZOR0007		\N	\N
178	2	2012-09-12 00:00:00	NA-02	43	84	93	ZOR0044		\N	\N
67	3	\N	ZI-06	66	68	45	ZOR0008		\N	\N
143	2	2012-09-12 00:00:00	M17-07	28	84	93	ZOR0029		\N	\N
75	2	2013-09-08 00:00:00	ZI6-17	22	77	52	ZOR0010		\N	\N
145	2	2012-09-12 00:00:00	NA-06	28	84	93	ZOR0030		\N	\N
79	3	\N	ZS4-1	22	80	25	ZOR0011		\N	\N
147	1	2012-09-12 00:00:00	ZS4-7	28	80	\N	ZOR0031		\N	\N
83	3	\N	M17-02	43	84	25	ZOR0012		\N	\N
89	2	2013-09-08 00:00:00	ZI6-06	88	51	52	ZOR0013		\N	\N
149	1	2012-09-12 00:00:00	MAn-02	28	84	\N	ZOR0032		\N	\N
180	1	2012-09-12 00:00:00	ZS4-5	39	80	\N	ZOR0045		\N	\N
92	3	\N	M17-05	91	84	93	ZOR0014		\N	\N
98	2	\N	ZA2-e	97	68	99	ZOR0015		\N	\N
151	2	2012-09-12 00:00:00	ZA2-c	97	\N	99	ZOR0033		\N	\N
102	2	\N	MAn-04	101	84	103	ZOR0016		\N	\N
105	2	\N	ZS4-2	88	80	106	ZOR0017		\N	\N
153	2	2013-09-08 00:00:00	ZI6-29	97	77	155	ZOR0034		\N	\N
109	2	\N	ZS4-6	108	80	25	ZOR0018		\N	\N
113	3	\N	ZS4-9	112	80	106	ZOR0019		\N	\N
117	3	\N	ZS4-12	116	80	106	ZOR0020	In culture (shaking, BHI), grows in clumps rather than homogenous (4/25/12-ZS)	\N	\N
182	2	2012-09-12 00:00:00	M17-01	39	84	93	ZOR0046		\N	\N
121	2	\N	ROB-A1	120	122	106	ZOR0021	No permanent stock	\N	\N
125	2	\N	ROB-10	124	80	106	ZOR0022	No permanent stock	\N	\N
217	2	\N	SWZG02.006	216	\N	\N	ZNC0032		\N	\N
160	2	2013-09-08 00:00:00	ZI6-12	157	161	52	ZOR0036		\N	\N
135	2	2012-09-12 00:00:00	ZA2-a	28	\N	99	ZOR0025		\N	\N
197	2	2012-09-12 00:00:00	ZS4-10	112	80	106	ZOR0052		\N	\N
137	2	2012-09-12 00:00:00	ZA2-d	28	\N	99	ZOR0026		\N	\N
163	2	2013-09-08 00:00:00	ZI6-35	157	164	64	ZOR0037		\N	\N
184	2	2012-09-12 00:00:00	M17-06	39	84	93	ZOR0047		\N	\N
166	2	2013-09-08 00:00:00	ZI6-40	28	51	64	ZOR0038		\N	\N
221	2	\N	SWZG02.015	216	\N	\N	ZNC0037		\N	\N
168	2	2013-09-08 00:00:00	ZI6-31	28	77	155	ZOR0039		\N	\N
170	2	2013-09-08 00:00:00	ZI6-07	43	58	52	ZOR0040		\N	\N
172	1	2012-09-12 00:00:00	MAn-03	43	84	\N	ZOR0041		\N	\N
174	1	2012-09-12 00:00:00	ZS4-3	43	80	\N	ZOR0042		\N	\N
176	1	2012-09-12 00:00:00	ZS4-4	43	80	\N	ZOR0043		\N	\N
199	2	2012-09-12 00:00:00	NA-04	91	84	93	ZOR0053		\N	\N
186	2	2012-09-12 00:00:00	NA-01	39	84	93	ZOR0048		\N	\N
188	2	2012-09-12 00:00:00	NA-05	39	84	93	ZOR0049		\N	\N
191	2	2013-09-08 00:00:00	ZI6-25	190	192	155	ZOR0050	Associated with human skin	\N	\N
206	2	\N	SWZG01.007	120	\N	\N	ZNC0007		\N	\N
195	2	2013-09-08 00:00:00	ZI6-14A	194	77	52	ZOR0051	Associated with human skin, but also in environmental water	\N	\N
209	2	\N	SWZG01.008	208	\N	\N	ZNC0008		\N	\N
213	2	\N	SWZG02.002	212	\N	\N	ZNC0028		\N	\N
132	2	\N	KG4dpf-15, 4dpf-15	39	133	\N	ZOR0024		\N	\N
236	3	\N	ZF1EF01, Z03 (Zac)	157	225	25	ZWU0020	\N	\N	\N
29	3	\N	TC021	28	32	33	ZOR0001	Passaged once from original TC collection isolated by Travis Carney	\N	\N
234	2	\N	T1N1E05	233	\N	\N	ZWU0011		\N	\N
128	4	\N	KG3dpf.1	127	130	\N	ZOR0023		\N	\N
247	1	\N	T1E1A03	246	\N	\N	ZWU0001		\N	\N
229	4	\N	ZF1EB02, Z06 (Zac)	48	225	230	ZWU0009	\N	\N	\N
251	1	\N	T1E1B07	28	\N	\N	ZWU0002		\N	\N
253	1	\N	M2E1A04	101	\N	\N	MWU0001		\N	\N
255	1	\N	T1E1D10	101	\N	\N	ZWU0003		\N	\N
258	1	\N	T1E1H07	28	\N	\N	ZWU0004		\N	\N
260	1	\N	This clone recovered accidentally while trying to recover Chitinibacter clone ZF1ED01 from glycerol plate	22	\N	\N	ZWU0005	glycerol stock made by Chad Trent (JFR: origin unknown - do not use)	\N	\N
264	1	\N	M2E1F06	263	\N	\N	MWU0002		\N	\N
267	1	\N	TSFNXAE.F12	266	\N	\N	ZWU0007		\N	\N
269	1	\N	M2E1G02	266	\N	\N	MWU0003		\N	\N
271	1	\N	T1E1A06	28	\N	\N	ZWU0008		\N	\N
274	1	\N	M2E1D03	263	\N	\N	MWU0004		\N	\N
276	1	\N	T1E1A07	28	\N	\N	ZWU0010		\N	\N
158	3	2013-09-08 00:00:00	ZI6-02	157	51	52	ZOR0035	Grew in Brucella Broth+10%FBS liquid culture 30C	\N	\N
139	3	2012-09-12 00:00:00	M17-03	28	84	93	ZOR0027	where does this box end up?	\N	\N
283	1	\N	T1E1C07	282	\N	\N	ZWU0013		\N	\N
285	1	\N	M2E1D05	263	\N	\N	MWU0005		\N	\N
288	1	\N	T1N1G10	287	\N	\N	ZWU0014		\N	\N
290	1	\N	T1N1D03	22	\N	\N	ZWU0015		\N	\N
292	1	\N	ZF1EF05	28	\N	\N	ZWU0016		\N	\N
294	1	\N	ZFMB1AE.E7, ZF1EE07	39	\N	\N	ZWU0017	same as ZWR0006?	\N	\N
296	1	\N	T1N1F08	282	\N	\N	ZWU0018		\N	\N
299	1	\N	This clone recovered accidentally while trying to recover Chitinibacter clone ZF1ED01 from glycerol plate	22	\N	\N	ZWU0019	glycerol stock made by Jessica Russell (JFR: origin unknown - do not use)	\N	\N
301	1	\N	SWZG01.001	28	\N	\N	ZNC0001		\N	\N
302	1	\N	SWZG01.002	\N	\N	\N	ZNC0002		\N	\N
305	1	\N	SWZG01.003	28	\N	\N	ZNC0003		\N	\N
307	1	\N	SWZG01.004	39	\N	\N	ZNC0004		\N	\N
309	1	\N	SWZG01.005	39	\N	\N	ZNC0005		\N	\N
314	1	\N	SWZG01.009	39	\N	\N	ZNC0009		\N	\N
316	1	\N	SWZG01.010	28	\N	\N	ZNC0010		\N	\N
318	1	\N	SWZG01.011	28	\N	\N	ZNC0011		\N	\N
320	1	\N	SWZG01.012	208	\N	\N	ZNC0012		\N	\N
322	1	\N	SWZG01.013	120	\N	\N	ZNC0013		\N	\N
324	1	\N	SWZG01.014	28	\N	\N	ZNC0014		\N	\N
326	1	\N	SWZG01.015	39	\N	\N	ZNC0015		\N	\N
329	1	\N	SWZG01.016	328	\N	\N	ZNC0016		\N	\N
331	1	\N	SWZG01.017	208	\N	\N	ZNC0017		\N	\N
333	1	\N	SWZG01.018	39	\N	\N	ZNC0018		\N	\N
335	1	\N	SWZG01.019	201	\N	\N	ZNC0019		\N	\N
337	1	\N	SWZG01.020	208	\N	\N	ZNC0020		\N	\N
339	1	\N	SWZG01.021	208	\N	\N	ZNC0021		\N	\N
341	1	\N	SWZG01.022	39	\N	\N	ZNC0022		\N	\N
343	1	\N	SWZG01.023	39	\N	\N	ZNC0023		\N	\N
345	1	\N	SWZG01.024	39	\N	\N	ZNC0024		\N	\N
347	1	\N	SWZG01.025	39	\N	\N	ZNC0025		\N	\N
350	1	\N	SWZG01.026	349	\N	\N	ZNC0026		\N	\N
352	1	\N	SWZG02.001	112	\N	\N	ZNC0027		\N	\N
355	1	\N	SWZG02.003	112	\N	\N	ZNC0029		\N	\N
356	1	\N	SWZG02.004	\N	\N	\N	ZNC0030		\N	\N
360	1	\N	SWZG02.005	359	\N	\N	ZNC0031		\N	\N
365	1	\N	SWZG02.007	364	\N	\N	ZNC0033		\N	\N
368	1	\N	SWZG02.008	112	\N	\N	ZNC0034		\N	\N
370	1	\N	SWZG02.009	216	\N	\N	ZNC0035		\N	\N
372	1	\N	SWZG02.012	112	\N	\N	ZNC0036		\N	\N
375	1	\N	SWZG02.016	112	\N	\N	ZNC0038		\N	\N
377	1	\N	SWZG02.017	216	\N	\N	ZNC0039		\N	\N
379	1	\N	SWZG02.019	112	\N	\N	ZNC0040		\N	\N
381	1	\N	SWZG02.021	359	\N	\N	ZNC0041		\N	\N
384	1	\N	SWZG02.023	359	\N	\N	ZNC0042		\N	\N
386	1	\N	SWZG02.024	359	\N	\N	ZNC0043		\N	\N
388	1	\N	SWZG02.026	359	\N	\N	ZNC0044		\N	\N
23	3	\N	This clone recovered accidentally while trying to recover clone ZF1ED01 from glycerol plate	22	\N	25	ZWU0023	DO NOT USE!  Not in stock box.\r\nSent as Chitinbacter, 16S seqeunce indicates Plesiomonas (Sandi: this might actually be ZWU0005? My version of ZF1ED01 is a Plesiomonas)(JFR: origin unknown - do not use)	\N	\N
279	2	\N	TSFN1AE.C5, T1E1C05	43	\N	\N	ZWU0012	Generally, DON'T USE!  Better Shewanella is ZOR0012.  This strain  (ZWU0012) is a strain passaged through mouse in John Rawl's study.  Originally isolated from zebrafish though.  	\N	\N
56	5	2013-09-08 00:00:00	ZI6-20	537	58	59	ZOR0006	This strain looks to be from a novel class of Firmicutes.  Likely CK_1C4_19.  Previous assignment as Haloplasma was based off short, poor-quality sequence.  Closest related class seems to be Erysipelotrichia [49% conf. RDP]. Cant grow from stock.	\N	\N
224	5	\N	ZF1EE07, Z02 (Zac)	39	225	226	ZWU0006	Unable to grow in liquid after 4C O/N	\N	\N
202	5	\N	SWZG01.006	201	\N	\N	ZNC0006	Unable to grow in liquid after 4C O/N	\N	\N
49	3	2013-09-08 00:00:00	ZI6-05	48	51	52	ZOR0005	Grew in Brucella Broth+10%FBS liquid culture 30C	\N	\N
\.


--
-- Data for Name: strain_genotype; Type: TABLE DATA; Schema: public; Owner: ndunn
--

COPY strain_genotype (id, version, name, note) FROM stdin;
\.


--
-- Name: category_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY category
    ADD CONSTRAINT category_name_key UNIQUE (name);


--
-- Name: category_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY category
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- Name: encrypted_data_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY encrypted_data
    ADD CONSTRAINT encrypted_data_pkey PRIMARY KEY (id);


--
-- Name: experiment_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY experiment
    ADD CONSTRAINT experiment_name_key UNIQUE (name);


--
-- Name: experiment_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY experiment
    ADD CONSTRAINT experiment_pkey PRIMARY KEY (id);


--
-- Name: genome_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY genome
    ADD CONSTRAINT genome_pkey PRIMARY KEY (id);


--
-- Name: genome_type_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY genome_type
    ADD CONSTRAINT genome_type_pkey PRIMARY KEY (id);


--
-- Name: genus_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY genus
    ADD CONSTRAINT genus_name_key UNIQUE (name);


--
-- Name: genus_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY genus
    ADD CONSTRAINT genus_pkey PRIMARY KEY (id);


--
-- Name: host_facility_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY host_facility
    ADD CONSTRAINT host_facility_name_key UNIQUE (name);


--
-- Name: host_facility_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY host_facility
    ADD CONSTRAINT host_facility_pkey PRIMARY KEY (id);


--
-- Name: host_genotype_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY host_genotype
    ADD CONSTRAINT host_genotype_name_key UNIQUE (name);


--
-- Name: host_genotype_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY host_genotype
    ADD CONSTRAINT host_genotype_pkey PRIMARY KEY (id);


--
-- Name: host_origin_genotypes_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY host_origin_genotypes
    ADD CONSTRAINT host_origin_genotypes_pkey PRIMARY KEY (host_origin_id, host_genotype_id);


--
-- Name: host_origin_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY host_origin
    ADD CONSTRAINT host_origin_pkey PRIMARY KEY (id);


--
-- Name: isolate_condition_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY isolate_condition
    ADD CONSTRAINT isolate_condition_pkey PRIMARY KEY (id);


--
-- Name: lab_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY lab
    ADD CONSTRAINT lab_name_key UNIQUE (name);


--
-- Name: lab_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY lab
    ADD CONSTRAINT lab_pkey PRIMARY KEY (id);


--
-- Name: location_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY location
    ADD CONSTRAINT location_name_key UNIQUE (name);


--
-- Name: location_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY location
    ADD CONSTRAINT location_pkey PRIMARY KEY (id);


--
-- Name: measured_value_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY measured_value
    ADD CONSTRAINT measured_value_pkey PRIMARY KEY (id);


--
-- Name: phylum_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY phylum
    ADD CONSTRAINT phylum_name_key UNIQUE (name);


--
-- Name: phylum_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY phylum
    ADD CONSTRAINT phylum_pkey PRIMARY KEY (id);


--
-- Name: researcher_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY researcher
    ADD CONSTRAINT researcher_pkey PRIMARY KEY (id);


--
-- Name: researcher_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY researcher_roles
    ADD CONSTRAINT researcher_roles_pkey PRIMARY KEY (researcher_id, role_id);


--
-- Name: researcher_username_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY researcher
    ADD CONSTRAINT researcher_username_key UNIQUE (username);


--
-- Name: role_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY role
    ADD CONSTRAINT role_name_key UNIQUE (name);


--
-- Name: role_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- Name: species_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY species
    ADD CONSTRAINT species_pkey PRIMARY KEY (id);


--
-- Name: stock_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY stock
    ADD CONSTRAINT stock_pkey PRIMARY KEY (id);


--
-- Name: strain_genotype_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY strain_genotype
    ADD CONSTRAINT strain_genotype_name_key UNIQUE (name);


--
-- Name: strain_genotype_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY strain_genotype
    ADD CONSTRAINT strain_genotype_pkey PRIMARY KEY (id);


--
-- Name: strain_name_key; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY strain
    ADD CONSTRAINT strain_name_key UNIQUE (name);


--
-- Name: strain_pkey; Type: CONSTRAINT; Schema: public; Owner: ndunn; Tablespace: 
--

ALTER TABLE ONLY strain
    ADD CONSTRAINT strain_pkey PRIMARY KEY (id);


--
-- Name: fk4a55fc986fbfb972; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY host_origin_genotypes
    ADD CONSTRAINT fk4a55fc986fbfb972 FOREIGN KEY (host_genotype_id) REFERENCES host_genotype(id);


--
-- Name: fk4a55fc98e9ff052; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY host_origin_genotypes
    ADD CONSTRAINT fk4a55fc98e9ff052 FOREIGN KEY (host_origin_id) REFERENCES host_origin(id);


--
-- Name: fk5db09ee5c83c4c1; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY genus
    ADD CONSTRAINT fk5db09ee5c83c4c1 FOREIGN KEY (phylum_id) REFERENCES phylum(id);


--
-- Name: fk68af71677e9e381; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY stock
    ADD CONSTRAINT fk68af71677e9e381 FOREIGN KEY (strain_id) REFERENCES strain(id);


--
-- Name: fk68af716e9e8a8ea; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY stock
    ADD CONSTRAINT fk68af716e9e8a8ea FOREIGN KEY (general_location_id) REFERENCES location(id);


--
-- Name: fk7ad8899d2aa7ad32; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY host_origin
    ADD CONSTRAINT fk7ad8899d2aa7ad32 FOREIGN KEY (host_facility_id) REFERENCES host_facility(id);


--
-- Name: fk7ad8899d4f9e7333; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY host_origin
    ADD CONSTRAINT fk7ad8899d4f9e7333 FOREIGN KEY (species_id) REFERENCES species(id);


--
-- Name: fk7cabd388dfb5aa13; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY researcher
    ADD CONSTRAINT fk7cabd388dfb5aa13 FOREIGN KEY (lab_id) REFERENCES lab(id);


--
-- Name: fk8849413caa96c833; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY species
    ADD CONSTRAINT fk8849413caa96c833 FOREIGN KEY (genus_id) REFERENCES genus(id);


--
-- Name: fk9627ff463eeffb21; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY researcher_roles
    ADD CONSTRAINT fk9627ff463eeffb21 FOREIGN KEY (researcher_id) REFERENCES researcher(id);


--
-- Name: fk9627ff466cdb45a1; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY researcher_roles
    ADD CONSTRAINT fk9627ff466cdb45a1 FOREIGN KEY (role_id) REFERENCES role(id);


--
-- Name: fka6a21a4d3eeffb21; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY researcher_permissions
    ADD CONSTRAINT fka6a21a4d3eeffb21 FOREIGN KEY (researcher_id) REFERENCES researcher(id);


--
-- Name: fkac5e95cd33ae8d18; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY species_host_genotype
    ADD CONSTRAINT fkac5e95cd33ae8d18 FOREIGN KEY (species_genotypes_id) REFERENCES species(id);


--
-- Name: fkac5e95cd6fbfb972; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY species_host_genotype
    ADD CONSTRAINT fkac5e95cd6fbfb972 FOREIGN KEY (host_genotype_id) REFERENCES host_genotype(id);


--
-- Name: fkb5861cf770e62030; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY genome
    ADD CONSTRAINT fkb5861cf770e62030 FOREIGN KEY (genome_type_id) REFERENCES genome_type(id);


--
-- Name: fkb5861cf777e9e381; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY genome
    ADD CONSTRAINT fkb5861cf777e9e381 FOREIGN KEY (strain_id) REFERENCES strain(id);


--
-- Name: fkb8302e871afcfd4c; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY isolate_condition
    ADD CONSTRAINT fkb8302e871afcfd4c FOREIGN KEY (isolated_by_id) REFERENCES researcher(id);


--
-- Name: fkcad5417529128baa; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY strain
    ADD CONSTRAINT fkcad5417529128baa FOREIGN KEY (isolate_condition_id) REFERENCES isolate_condition(id);


--
-- Name: fkcad541754f8a9a2c; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY strain
    ADD CONSTRAINT fkcad541754f8a9a2c FOREIGN KEY (parent_strain_id) REFERENCES strain(id);


--
-- Name: fkcad54175aa96c833; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY strain
    ADD CONSTRAINT fkcad54175aa96c833 FOREIGN KEY (genus_id) REFERENCES genus(id);


--
-- Name: fkcad54175e9ff052; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY strain
    ADD CONSTRAINT fkcad54175e9ff052 FOREIGN KEY (host_origin_id) REFERENCES host_origin(id);


--
-- Name: fkcad54175f42a5acc; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY strain
    ADD CONSTRAINT fkcad54175f42a5acc FOREIGN KEY (strain_genotype_id) REFERENCES strain_genotype(id);


--
-- Name: fkcc54eb877e9e381; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY measured_value
    ADD CONSTRAINT fkcc54eb877e9e381 FOREIGN KEY (strain_id) REFERENCES strain(id);


--
-- Name: fkcc54eb8aec16d21; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY measured_value
    ADD CONSTRAINT fkcc54eb8aec16d21 FOREIGN KEY (category_id) REFERENCES category(id);


--
-- Name: fkcc54eb8b2082b01; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY measured_value
    ADD CONSTRAINT fkcc54eb8b2082b01 FOREIGN KEY (experiment_id) REFERENCES experiment(id);


--
-- Name: fkead9d23b6cdb45a1; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY role_permissions
    ADD CONSTRAINT fkead9d23b6cdb45a1 FOREIGN KEY (role_id) REFERENCES role(id);


--
-- Name: fkfae9dbfd3eeffb21; Type: FK CONSTRAINT; Schema: public; Owner: ndunn
--

ALTER TABLE ONLY experiment
    ADD CONSTRAINT fkfae9dbfd3eeffb21 FOREIGN KEY (researcher_id) REFERENCES researcher(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

